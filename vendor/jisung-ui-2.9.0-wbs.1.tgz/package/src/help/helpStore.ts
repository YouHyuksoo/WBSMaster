/**
 * @file src/help/helpStore.ts
 * @description 화면 도움말 패널 열림 상태. 헤더 HelpButton 이 열고 셸에 한 번 둔 HelpPanel 이 읽는다.
 */
import { create } from "zustand";
import type { HelpTab } from "./help";

interface HelpState {
  isOpen: boolean;
  tab: HelpTab;
  /** 다른 곳(AI 출처 등)에서 특정 문서를 열 때 — 현재 화면 대신 이 문서 */
  overrideDocKey?: string;
  overrideHeadingSlug?: string;
  openHelp: () => void;
  /** 문서 키·탭을 지정해 열고, headingSlug 가 있으면 그 제목으로 스크롤 */
  openHelpFor: (docKey: string, tab: HelpTab, headingSlug?: string) => void;
  closeHelp: () => void;
  setTab: (tab: HelpTab) => void;
}

export const useHelpStore = create<HelpState>((set) => ({
  isOpen: false,
  tab: "user",
  overrideDocKey: undefined,
  overrideHeadingSlug: undefined,
  openHelp: () => set({ isOpen: true, overrideDocKey: undefined, overrideHeadingSlug: undefined }),
  openHelpFor: (docKey, tab, headingSlug) => set({ isOpen: true, tab, overrideDocKey: docKey, overrideHeadingSlug: headingSlug }),
  closeHelp: () => set({ isOpen: false, overrideDocKey: undefined, overrideHeadingSlug: undefined }),
  setTab: (tab) => set({ tab }),
}));
