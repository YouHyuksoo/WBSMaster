/**
 * @file src/help/help.ts
 * @description 화면 도움말(markdown) 공용 규칙 — 문서 경로, 목차(manifest), frontmatter 파서.
 * HANES apps/frontend/src/lib/help.ts 에서 옮겼다. 탭(대상 독자)은 제품마다 정한다.
 */

/** 도움말 탭(대상 독자). HANES 는 user/operator/system 을 쓴다. */
export type HelpTab = string;

export interface HelpTabDef {
  key: HelpTab;
  /** i18n 키(예: help.tabUser) */
  labelKey: string;
  /** 키가 없을 때 보일 이름 */
  fallback: string;
}

export const DEFAULT_HELP_TABS: HelpTabDef[] = [
  { key: "user", labelKey: "help.tabUser", fallback: "사용자" },
  { key: "operator", labelKey: "help.tabOperator", fallback: "운영자" },
  { key: "system", labelKey: "help.tabSystem", fallback: "시스템" },
];

export interface HelpManifestItem {
  /** 문서 키(보통 메뉴 코드). 파일 이름이 된다. */
  menuCode: string;
  title: string;
  /** 언어별 제목(예: { vi: "...", es: "..." }). 없는 언어는 title 을 쓴다. */
  titles?: Record<string, string>;
  path?: string;
  /** 지정한 탭에서만 보이는 항목. 생략하면 마지막 탭(system 등 별도 문서)을 뺀 모든 탭에 보인다. */
  audience?: HelpTab;
}

export interface HelpManifestCategory {
  key: string;
  title: string;
  /** 언어별 제목. 없는 언어는 title 을 쓴다. */
  titles?: Record<string, string>;
  items: HelpManifestItem[];
}

export interface HelpManifest {
  version: number;
  categories: HelpManifestCategory[];
}

/** 현재 언어의 목차 제목(언어 코드는 앞부분만 본다: vi-VN → vi). 없으면 기본 title. */
export function localizedTitle(entry: { title: string; titles?: Record<string, string> }, lang?: string): string {
  const code = lang?.toLowerCase().split("-")[0];
  return (code && entry.titles?.[code]) || entry.title;
}

/** 문서 키·탭·언어로 public 아래 markdown 경로를 만든다. */
export type HelpDocPath = (tab: HelpTab, docKey: string, lang: string) => string;

/** 기본 경로: /help/<탭>/<언어>/<문서 키>.md */
export const defaultHelpDocPath: HelpDocPath = (tab, docKey, lang) => `/help/${tab}/${lang}/${docKey}.md`;

/**
 * 탭과 제목 부분일치(대소문자 무시)로 목차를 거른다.
 * audience 가 없는 항목은 `sharedTabs` 에 든 탭에서만 보인다(HANES: user·operator).
 */
export function filterManifest(
  manifest: HelpManifest,
  query: string,
  audience: HelpTab,
  sharedTabs: readonly HelpTab[] = ["user", "operator"],
  lang?: string,
): HelpManifestCategory[] {
  const q = query.trim().toLowerCase();
  return manifest.categories
    .map((cat) => {
      const audienceItems = cat.items.filter((item) => (item.audience ? item.audience === audience : sharedTabs.includes(audience)));
      return {
        ...cat,
        items: q
          ? audienceItems.filter((item) => localizedTitle(item, lang).toLowerCase().includes(q) || item.menuCode.toLowerCase().includes(q))
          : audienceItems,
      };
    })
    .filter((cat) => cat.items.length > 0 || (q.length > 0 && localizedTitle(cat, lang).toLowerCase().includes(q)));
}

export interface HelpMeta {
  menuCode?: string;
  audience?: HelpTab;
  title?: string;
  summary?: string;
  tags?: string[];
  keywords?: string[];
  related?: string[];
}

/**
 * 경량 frontmatter 파서 — 최상단 `---\n...\n---\n` 블록을 분리한다.
 * 스칼라 값과 `[a, b, c]` 인라인 배열만 지원. frontmatter 가 없으면 { meta: {}, body: raw }.
 */
export function parseHelpDoc(raw: string): { meta: HelpMeta; body: string } {
  const match = /^﻿?---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(raw);
  if (!match) return { meta: {}, body: raw };
  const [, fm, body] = match;
  const meta: Record<string, unknown> = {};
  for (const line of fm.split(/\r?\n/)) {
    const m = /^([A-Za-z][\w]*)\s*:\s*(.*)$/.exec(line.trim());
    if (!m) continue;
    const [, key, rawVal] = m;
    const val = rawVal.trim();
    if (val.startsWith("[") && val.endsWith("]")) {
      meta[key] = val
        .slice(1, -1)
        .split(",")
        .map((s) => s.trim().replace(/^["']|["']$/g, ""))
        .filter(Boolean);
    } else {
      meta[key] = val.replace(/^["']|["']$/g, "");
    }
  }
  return { meta: meta as HelpMeta, body: body ?? "" };
}

/** 문서 제목: frontmatter title → 첫 # 제목 → fallback */
export function getHelpDocumentTitle(content: string, fallback = "Help"): string {
  const { meta, body } = parseHelpDoc(content);
  const heading = body.match(/^#\s+(.+?)\s*#*\s*$/m)?.[1]?.trim();
  return meta.title?.trim() || heading || fallback;
}
