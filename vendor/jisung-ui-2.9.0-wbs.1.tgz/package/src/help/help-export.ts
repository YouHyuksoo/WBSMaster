/**
 * @file src/help/help-export.ts
 * @description 보고 있는 도움말 문서를 HTML 파일로 내려받거나 인쇄(PDF 저장)한다. HANES 에서 옮겼다(한 문서 분만).
 * 화면의 class·style·이벤트 속성·스크립트는 빼고 문서 본문만 옮긴다.
 */

function escapeHtml(value: string): string {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}

function safeFileName(value: string): string {
  return (
    value
      .trim()
      .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "-")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .slice(0, 100) || "help"
  );
}

function copySafeHelpMarkup(source: HTMLElement): HTMLElement {
  const clone = source.cloneNode(true) as HTMLElement;
  clone.querySelectorAll("script, style, iframe, object, embed, form").forEach((node) => node.remove());
  clone.querySelectorAll("mark[data-help-search-match]").forEach((mark) => {
    mark.replaceWith(...Array.from(mark.childNodes));
  });

  const elements = [clone, ...Array.from(clone.querySelectorAll<HTMLElement>("*"))];
  for (const element of elements) {
    for (const attribute of Array.from(element.attributes)) {
      const name = attribute.name.toLowerCase();
      const value = attribute.value.trim();
      if (name === "class" || name === "style" || name.startsWith("on") || name === "srcdoc") {
        element.removeAttribute(attribute.name);
        continue;
      }
      if ((name === "href" || name === "src") && /^(javascript|vbscript|data:text\/html):/i.test(value)) {
        element.removeAttribute(attribute.name);
        continue;
      }
      if ((name === "href" || name === "src") && value.startsWith("/")) {
        element.setAttribute(attribute.name, new URL(value, window.location.origin).href);
      }
    }
    if (element.tagName === "A" && element.getAttribute("href")?.startsWith("http")) {
      element.setAttribute("target", "_blank");
      element.setAttribute("rel", "noopener noreferrer");
    }
  }
  return clone;
}

function documentStyles(): string {
  return `
    :root { color-scheme: light; }
    body { max-width: 900px; margin: 0 auto; padding: 40px 48px; color: #172033; font: 15px/1.7 system-ui, -apple-system, "Segoe UI", sans-serif; }
    h1, h2, h3, h4 { color: #102a43; line-height: 1.3; page-break-after: avoid; }
    h1 { margin: 0 0 28px; padding-bottom: 14px; border-bottom: 2px solid #1d4ed8; font-size: 30px; }
    h2 { margin-top: 30px; padding-bottom: 7px; border-bottom: 1px solid #cbd5e1; font-size: 22px; }
    h3 { margin-top: 24px; font-size: 18px; }
    p, ul, ol, blockquote, pre, table { margin: 12px 0; }
    li { margin: 4px 0; }
    a { color: #1d4ed8; text-decoration: underline; }
    blockquote { padding: 10px 16px; border-left: 4px solid #3b82f6; background: #eff6ff; color: #334155; }
    code, pre { font-family: ui-monospace, SFMono-Regular, Consolas, monospace; }
    code { padding: 2px 5px; border-radius: 4px; background: #eef2f7; font-size: .9em; }
    pre { padding: 14px; overflow-wrap: anywhere; white-space: pre-wrap; border-radius: 8px; background: #0f172a; color: #f8fafc; }
    pre code { padding: 0; background: transparent; color: inherit; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th, td { padding: 8px 10px; border: 1px solid #cbd5e1; text-align: left; vertical-align: top; }
    th { background: #f1f5f9; }
    img { max-width: 100%; height: auto; }
    hr { margin: 24px 0; border: 0; border-top: 1px solid #cbd5e1; }
    @page { size: A4; margin: 16mm; }
    @media print {
      body { max-width: none; padding: 0; font-size: 10.5pt; }
      table, pre, blockquote, img { break-inside: avoid; }
      a { color: inherit; }
    }
  `;
}

export function downloadHelpAsHtml(source: HTMLElement, title: string): void {
  const safeMarkup = copySafeHelpMarkup(source);
  const content = safeMarkup.innerHTML;
  const titledContent = safeMarkup.querySelector("h1") ? content : `<h1>${escapeHtml(title)}</h1>${content}`;
  const html = `<!doctype html>
<html lang="${escapeHtml(document.documentElement.lang || "ko")}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <style>${documentStyles()}</style>
</head>
<body>
  <main class="help-md">${titledContent}</main>
</body>
</html>`;
  const url = URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${safeFileName(title)}.html`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function printHelpAsPdf(source: HTMLElement, title: string): void {
  document.getElementById("help-export-print-host")?.remove();
  document.getElementById("help-export-print-style")?.remove();

  const host = document.createElement("main");
  host.id = "help-export-print-host";
  host.className = "help-md";
  const safeMarkup = copySafeHelpMarkup(source);
  if (!safeMarkup.querySelector("h1")) {
    const heading = document.createElement("h1");
    heading.textContent = title;
    host.appendChild(heading);
  }
  host.appendChild(safeMarkup);

  const style = document.createElement("style");
  style.id = "help-export-print-style";
  style.textContent = `
    #help-export-print-host { display: none; }
    @page { size: A4; margin: 16mm; }
    @media print {
      html, body { width: auto !important; height: auto !important; overflow: visible !important; background: #fff !important; }
      body > *:not(#help-export-print-host) { display: none !important; }
      #help-export-print-host { display: block !important; position: static !important; width: auto !important; max-width: none !important; height: auto !important; margin: 0 !important; padding: 0 !important; overflow: visible !important; color: #172033 !important; font: 10.5pt/1.6 system-ui, -apple-system, "Segoe UI", sans-serif !important; }
      #help-export-print-host h1, #help-export-print-host h2, #help-export-print-host h3 { color: #102a43 !important; page-break-after: avoid; }
      #help-export-print-host h1 { padding-bottom: 10px; border-bottom: 2px solid #1d4ed8; font-size: 24pt; }
      #help-export-print-host h2 { margin-top: 24px; padding-bottom: 6px; border-bottom: 1px solid #cbd5e1; font-size: 17pt; }
      #help-export-print-host table { width: 100%; border-collapse: collapse; font-size: 9pt; }
      #help-export-print-host th, #help-export-print-host td { padding: 6px 8px; border: 1px solid #94a3b8; text-align: left; vertical-align: top; }
      #help-export-print-host th { background: #f1f5f9 !important; }
      #help-export-print-host pre { padding: 10px; white-space: pre-wrap; overflow-wrap: anywhere; background: #f1f5f9 !important; color: #0f172a !important; }
      #help-export-print-host code { font-family: ui-monospace, SFMono-Regular, Consolas, monospace; }
      #help-export-print-host img { max-width: 100% !important; height: auto !important; }
      #help-export-print-host blockquote { padding: 8px 12px; border-left: 3px solid #3b82f6; background: #eff6ff !important; }
      #help-export-print-host a { color: inherit !important; }
      #help-export-print-host tr, #help-export-print-host pre, #help-export-print-host blockquote, #help-export-print-host img { break-inside: avoid; }
    }
  `;
  document.head.appendChild(style);
  document.body.appendChild(host);

  const previousTitle = document.title;
  document.title = title;
  let cleaned = false;
  const cleanup = () => {
    if (cleaned) return;
    cleaned = true;
    host.remove();
    style.remove();
    document.title = previousTitle;
  };
  window.addEventListener("afterprint", cleanup, { once: true });
  window.setTimeout(cleanup, 60_000);
  window.print();
}
