/**
 * @file src/help/HelpLibrary.tsx
 * @description 전체 도움말 화면 본문 — 왼쪽 목차(탭·검색), 오른쪽 문서. HANES (authenticated)/help/page.tsx 에서 옮겼다.
 * 제목줄은 제품이 Page/PageHeader 로 감싼다. 휴대폰에서는 목차 위, 문서 아래로 쌓는다.
 */
"use client";

import { useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { BookOpen, Search } from "lucide-react";
import { Card, CardContent } from "../ui/Card";
import Input from "../ui/Input";
import { DEFAULT_HELP_TABS, defaultHelpDocPath, filterManifest, getHelpDocumentTitle, localizedTitle, type HelpDocPath, type HelpTab, type HelpTabDef } from "./help";
import { useHelpDoc, useHelpManifest } from "./useHelpDoc";
import HelpExportActions from "./HelpExportActions";
import MarkdownRenderer from "./MarkdownRenderer";

export interface HelpLibraryProps {
  tabs?: HelpTabDef[];
  /** audience 없는 목차 항목이 보이는 탭 */
  sharedTabs?: HelpTab[];
  manifestUrl?: string;
  docPath?: HelpDocPath;
  /** 처음 열 문서 키 */
  initialDocKey?: string;
}

export default function HelpLibrary({
  tabs = DEFAULT_HELP_TABS,
  sharedTabs,
  manifestUrl,
  docPath = defaultHelpDocPath,
  initialDocKey,
}: HelpLibraryProps) {
  const { t, i18n } = useTranslation();
  const { manifest, loading } = useHelpManifest(manifestUrl);
  const [tab, setTab] = useState<HelpTab>(tabs[0]?.key ?? "user");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string | undefined>(initialDocKey);
  const contentRef = useRef<HTMLDivElement | null>(null);
  const shared = sharedTabs ?? tabs.map((item) => item.key);

  const categories = useMemo(() => (manifest ? filterManifest(manifest, query, tab, shared, i18n.language) : []), [manifest, query, tab, shared, i18n.language]);
  const { content, loading: docLoading, notFound } = useHelpDoc(selected, tab, docPath);
  const selectedTitle = manifest?.categories.flatMap((category) => category.items).find((item) => item.menuCode === selected);
  const fallbackTitle = selectedTitle ? localizedTitle(selectedTitle, i18n.language) : t("help.title", "도움말");
  const exportTitle = content ? getHelpDocumentTitle(content, fallbackTitle) : fallbackTitle;

  return (
    <div className="grid min-h-0 flex-1 gap-4 lg:grid-cols-12">
      <Card className="min-h-0 overflow-hidden lg:col-span-4" padding="none">
        <CardContent className="flex h-full flex-col overflow-hidden p-3">
          {tabs.length > 1 ? (
            <div className="mb-2 flex border-b border-border" role="tablist">
              {tabs.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  role="tab"
                  aria-selected={tab === item.key}
                  onClick={() => {
                    setTab(item.key);
                    setSelected(undefined);
                  }}
                  className={`flex-1 px-3 py-2 text-sm font-medium transition-colors ${
                    tab === item.key ? "border-b-2 border-primary text-primary" : "text-text-muted hover:text-text"
                  }`}
                >
                  {t(item.labelKey, item.fallback)}
                </button>
              ))}
            </div>
          ) : null}
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label={t("help.searchPlaceholder", "도움말 검색")}
            placeholder={t("help.searchPlaceholder", "도움말 검색")}
            leftIcon={<Search className="h-4 w-4" />}
            fullWidth
            className="mb-2"
          />
          <nav className="min-h-0 flex-1 overflow-y-auto" aria-label={t("help.contents", "도움말 목차")}>
            {loading ? (
              <p className="p-4 text-sm text-text-muted">{t("common.loading", "데이터를 불러오고 있습니다.")}</p>
            ) : (
              categories.map((cat) => (
                <div key={cat.key} className="mb-3">
                  <p className="px-2 py-1 text-xs font-semibold text-text-muted">{localizedTitle(cat, i18n.language)}</p>
                  {cat.items.map((it) => (
                    <button
                      key={it.menuCode}
                      type="button"
                      aria-current={selected === it.menuCode ? "true" : undefined}
                      onClick={() => setSelected(it.menuCode)}
                      className={`w-full rounded px-3 py-1.5 text-left text-sm transition-colors ${
                        selected === it.menuCode ? "bg-primary/10 font-medium text-primary" : "text-text hover:bg-surface"
                      }`}
                    >
                      {localizedTitle(it, i18n.language)}
                    </button>
                  ))}
                </div>
              ))
            )}
          </nav>
        </CardContent>
      </Card>

      <Card className="min-h-0 overflow-hidden lg:col-span-8" padding="none">
        <CardContent className="h-full overflow-y-auto p-5">
          {!selected ? (
            <div className="flex h-full min-h-48 flex-col items-center justify-center gap-3 text-text-muted">
              <BookOpen className="h-12 w-12 opacity-20" aria-hidden="true" />
              <p className="text-sm">{t("help.selectItem", "좌측에서 도움말 항목을 선택하세요.")}</p>
            </div>
          ) : docLoading ? (
            <div className="flex h-full min-h-48 items-center justify-center">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            </div>
          ) : notFound || !content ? (
            <p className="text-sm text-text-muted">{t("help.notReady", "이 화면의 도움말은 준비 중입니다.")}</p>
          ) : (
            <>
              <div className="mb-3 flex justify-end border-b border-border pb-3">
                <HelpExportActions contentRef={contentRef} title={exportTitle} disabled={docLoading || notFound || !content} />
              </div>
              <div ref={contentRef}>
                <MarkdownRenderer content={content} />
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
