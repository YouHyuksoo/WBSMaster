/**
 * @file src/help/HelpButton.tsx
 * @description 헤더 도움말 버튼(AppShellConfig.helpButton). 지금 화면의 도움말 패널을 연다.
 */
"use client";

import { HelpCircle } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useHelpStore } from "./helpStore";

export default function HelpButton({ label }: { label?: string }) {
  const { t } = useTranslation();
  const openHelp = useHelpStore((s) => s.openHelp);
  const name = label ?? t("help.title", "도움말");
  return (
    <button type="button" onClick={openHelp} className="p-2 rounded-md hover:bg-background transition-colors" aria-label={name} title={name}>
      <HelpCircle className="w-5 h-5 text-text-muted" />
    </button>
  );
}
