/**
 * @file src/help/MarkdownRenderer.tsx
 * @description 도움말 Markdown 렌더러 — GFM(표/코드/링크) + 제목 id(딥링크). HANES 에서 옮겼다.
 * HTML 원문(raw)은 그리지 않는다: 문서는 public 에서 읽으므로 스크립트·속성이 섞일 여지를 두지 않는다.
 *
 * components·plugins 는 모듈 상수다. 렌더마다 새 함수를 넘기면 React 가 다른 컴포넌트로 보고 본문 DOM 을 새로 만들어,
 * HelpPanel 찾기가 넣은 <mark> 가 개수 표시가 바뀌는 순간 사라진다.
 */
"use client";

import { memo } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeSlug from "rehype-slug";

export interface MarkdownRendererProps {
  content: string;
}

const REMARK_PLUGINS = [remarkGfm];
const REHYPE_PLUGINS = [rehypeSlug];

const COMPONENTS: Components = {
  h1: ({ id, children }) => <h1 id={id} className="mb-3 mt-1 scroll-mt-4 text-lg font-bold text-text">{children}</h1>,
  h2: ({ id, children }) => <h2 id={id} className="mb-2 mt-5 scroll-mt-4 border-b border-border pb-1 text-base font-semibold text-text">{children}</h2>,
  h3: ({ id, children }) => <h3 id={id} className="mb-1.5 mt-4 scroll-mt-4 text-sm font-semibold text-text">{children}</h3>,
  p: ({ children }) => <p className="my-2 text-text">{children}</p>,
  ul: ({ children }) => <ul className="my-2 list-disc space-y-1 pl-5">{children}</ul>,
  ol: ({ children }) => <ol className="my-2 list-decimal space-y-1 pl-5">{children}</ol>,
  li: ({ children }) => <li className="text-text">{children}</li>,
  a: ({ href, children }) => <a href={href} className="text-primary underline hover:opacity-80">{children}</a>,
  code: ({ children }) => <code className="rounded bg-surface px-1.5 py-0.5 font-mono text-[12px] text-primary">{children}</code>,
  pre: ({ children }) => <pre className="my-2 overflow-x-auto rounded-lg bg-slate-900 p-3 text-[12px] text-slate-100">{children}</pre>,
  table: ({ children }) => (
    <div className="my-3 overflow-x-auto">
      <table className="w-full border-collapse text-[13px]">{children}</table>
    </div>
  ),
  th: ({ children }) => <th className="border border-border bg-surface px-2 py-1 text-left font-semibold">{children}</th>,
  td: ({ children }) => <td className="border border-border px-2 py-1 align-top">{children}</td>,
  img: ({ src, alt }) => (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={typeof src === "string" ? src : ""} alt={alt ?? ""} className="my-2 max-w-full rounded-lg border border-border" />
  ),
  blockquote: ({ children }) => <blockquote className="my-2 border-l-4 border-primary/40 bg-surface/60 px-3 py-1.5 text-text-muted">{children}</blockquote>,
};

function MarkdownRenderer({ content }: MarkdownRendererProps) {
  return (
    <div className="help-md max-w-none text-sm leading-relaxed text-text">
      <ReactMarkdown remarkPlugins={REMARK_PLUGINS} rehypePlugins={REHYPE_PLUGINS} components={COMPONENTS}>
        {content}
      </ReactMarkdown>
    </div>
  );
}

export default memo(MarkdownRenderer);
