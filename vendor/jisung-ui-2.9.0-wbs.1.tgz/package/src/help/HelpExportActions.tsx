/**
 * @file src/help/HelpExportActions.tsx
 * @description 보고 있는 도움말 문서의 HTML 내려받기·PDF 저장 버튼.
 */
"use client";

import type { RefObject } from "react";
import { useTranslation } from "react-i18next";
import { Download, Printer } from "lucide-react";
import { downloadHelpAsHtml, printHelpAsPdf } from "./help-export";

export interface HelpExportActionsProps {
  contentRef: RefObject<HTMLElement | null>;
  title: string;
  disabled?: boolean;
}

const buttonClassName =
  "inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-2.5 text-xs font-medium text-text transition-colors hover:border-primary/50 hover:bg-primary/5 disabled:cursor-not-allowed disabled:opacity-40";

export default function HelpExportActions({ contentRef, title, disabled = false }: HelpExportActionsProps) {
  const { t } = useTranslation();
  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        disabled={disabled}
        onClick={() => {
          if (contentRef.current) downloadHelpAsHtml(contentRef.current, title);
        }}
        className={buttonClassName}
      >
        <Download className="h-3.5 w-3.5" aria-hidden="true" />
        {t("help.downloadHtml", "HTML 다운로드")}
      </button>
      <button
        type="button"
        disabled={disabled}
        onClick={() => {
          if (contentRef.current) printHelpAsPdf(contentRef.current, title);
        }}
        className={buttonClassName}
      >
        <Printer className="h-3.5 w-3.5" aria-hidden="true" />
        {t("help.savePdf", "PDF 저장")}
      </button>
    </div>
  );
}
