/**
 * @file src/help/HelpPanel.tsx
 * @description 오른쪽에서 열리는 화면 도움말 패널. HANES components/help/HelpPanel.tsx 에서 옮겼다.
 * 셸에 한 번만 둔다(AppShellConfig.overlays). 헤더 HelpButton 이 useHelpStore 로 연다.
 * 현재 화면의 문서 키는 제품이 resolveDocKey 로 정한다(보통 메뉴 코드).
 */
"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { useTranslation } from "react-i18next";
import { BookOpen, ChevronDown, ChevronUp, ExternalLink, Search, X } from "lucide-react";
import { navigateClientOnly } from "../shell/clientNavigation";
import { DEFAULT_HELP_TABS, defaultHelpDocPath, getHelpDocumentTitle, type HelpDocPath, type HelpTabDef } from "./help";
import { useHelpStore } from "./helpStore";
import { useHelpDoc } from "./useHelpDoc";
import HelpExportActions from "./HelpExportActions";
import MarkdownRenderer from "./MarkdownRenderer";

const MIN_SEARCH_LENGTH = 2;
const MARK_CLASS = "rounded bg-amber-200 px-0.5 text-slate-950 dark:bg-amber-300";
const ACTIVE_MARK_CLASS = "rounded bg-primary px-0.5 text-white ring-2 ring-primary/30";

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function clearHelpSearchMarks(root: HTMLElement | null) {
  if (!root) return;
  for (const mark of Array.from(root.querySelectorAll<HTMLElement>("mark[data-help-search-match]"))) {
    const parent = mark.parentNode;
    if (!parent) continue;
    parent.replaceChild(document.createTextNode(mark.textContent ?? ""), mark);
    parent.normalize();
  }
}

/** 본문 글자에서 검색어를 <mark> 로 감싸고 개수를 돌려준다. */
function highlightHelpMatches(root: HTMLElement | null, query: string) {
  if (!root) return 0;
  clearHelpSearchMarks(root);
  const keyword = query.trim();
  if (keyword.length < MIN_SEARCH_LENGTH) return 0;

  const pattern = new RegExp(escapeRegExp(keyword), "gi");
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes: Text[] = [];
  let current: Node | null = walker.nextNode();
  while (current) {
    const textNode = current as Text;
    const parent = textNode.parentElement;
    if (parent && !parent.closest("script, style, mark") && pattern.test(textNode.data)) nodes.push(textNode);
    pattern.lastIndex = 0;
    current = walker.nextNode();
  }

  let count = 0;
  for (const node of nodes) {
    const fragment = document.createDocumentFragment();
    const text = node.data;
    let lastIndex = 0;
    pattern.lastIndex = 0;
    let match: RegExpExecArray | null = pattern.exec(text);
    while (match) {
      if (match.index > lastIndex) fragment.appendChild(document.createTextNode(text.slice(lastIndex, match.index)));
      const mark = document.createElement("mark");
      mark.dataset.helpSearchMatch = "true";
      mark.className = MARK_CLASS;
      mark.textContent = match[0];
      fragment.appendChild(mark);
      count += 1;
      lastIndex = match.index + match[0].length;
      match = pattern.exec(text);
    }
    if (lastIndex < text.length) fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    node.parentNode?.replaceChild(fragment, node);
  }
  return count;
}

export interface HelpPanelProps {
  /** 현재 경로의 도움말 문서 키(보통 메뉴 코드). 없으면 '준비 중' */
  resolveDocKey: (pathname: string) => string | undefined;
  /** 탭(대상 독자). 기본은 HANES 의 사용자/운영자/시스템 */
  tabs?: HelpTabDef[];
  /** 탭마다 문서 키를 바꿔야 할 때(HANES: system 탭은 SYS_ADMIN 고정) */
  docKeyForTab?: (tab: string, docKey: string | undefined) => string | undefined;
  docPath?: HelpDocPath;
  /** '전체 도움말 보기' 경로. 없으면 버튼을 그리지 않는다. */
  helpPagePath?: string;
}

export default function HelpPanel({
  resolveDocKey,
  tabs = DEFAULT_HELP_TABS,
  docKeyForTab = (_tab, docKey) => docKey,
  docPath = defaultHelpDocPath,
  helpPagePath,
}: HelpPanelProps) {
  const { t } = useTranslation();
  const pathname = usePathname();
  const { isOpen, tab: storedTab, overrideDocKey, overrideHeadingSlug, closeHelp, setTab } = useHelpStore();
  // 제품이 탭을 줄였는데 저장된 탭이 목록에 없으면 첫 탭을 쓴다.
  const tab = tabs.some((item) => item.key === storedTab) ? storedTab : tabs[0]?.key ?? storedTab;
  const docKey = docKeyForTab(tab, overrideDocKey ?? resolveDocKey(pathname));
  const { content, loading, notFound } = useHelpDoc(isOpen ? docKey : undefined, tab, docPath);
  const panelTitle = t("help.title", "도움말");
  const exportTitle = content ? getHelpDocumentTitle(content, panelTitle) : panelTitle;
  const [width, setWidth] = useState(896);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchIndex, setSearchIndex] = useState(0);
  const [searchMatchCount, setSearchMatchCount] = useState(0);
  const contentRef = useRef<HTMLDivElement | null>(null);
  const closeRef = useRef<HTMLButtonElement | null>(null);

  // 왼쪽 경계를 끌어 너비 조절
  const startResize = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      const startX = e.clientX;
      const startW = width;
      const onMove = (ev: MouseEvent) => {
        setWidth(Math.min(Math.max(360, startW + (startX - ev.clientX)), Math.round(window.innerWidth * 0.95)));
      };
      const onUp = () => {
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
        document.body.style.userSelect = "";
      };
      document.body.style.userSelect = "none";
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
    },
    [width],
  );

  // 열리면 닫기 버튼으로 포커스, Escape 로 닫기
  useEffect(() => {
    if (!isOpen) return;
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeHelp();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [isOpen, closeHelp]);

  // 다른 곳에서 특정 제목으로 열었으면 본문을 읽은 뒤 그 제목으로 스크롤
  useEffect(() => {
    if (!isOpen || loading || !content || !overrideHeadingSlug) return;
    const id = overrideHeadingSlug;
    const timer = setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
    return () => clearTimeout(timer);
  }, [isOpen, loading, content, overrideHeadingSlug]);

  useEffect(() => {
    if (!isOpen || loading) {
      setSearchMatchCount(0);
      return;
    }
    const timer = setTimeout(() => {
      const count = highlightHelpMatches(contentRef.current, searchQuery);
      setSearchMatchCount(count);
      setSearchIndex((prev) => (count > 0 ? Math.min(prev, count - 1) : 0));
    }, 0);
    const root = contentRef.current;
    return () => {
      clearTimeout(timer);
      clearHelpSearchMarks(root);
    };
  }, [isOpen, loading, content, searchQuery, tab]);

  useEffect(() => {
    const root = contentRef.current;
    if (!root || searchMatchCount === 0) return;
    const matches = Array.from(root.querySelectorAll<HTMLElement>("mark[data-help-search-match]"));
    matches.forEach((match, index) => {
      const active = index === searchIndex;
      match.dataset.helpSearchActive = active ? "true" : "false";
      match.className = active ? ACTIVE_MARK_CLASS : MARK_CLASS;
    });
    matches[searchIndex]?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [searchIndex, searchMatchCount]);

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-[9990] bg-black/40 print:hidden" onClick={closeHelp} aria-hidden />
      <aside
        role="dialog"
        aria-modal="true"
        aria-label={panelTitle}
        style={{ width }}
        className="fixed right-0 top-0 z-[9991] flex h-screen max-w-[95vw] flex-col border-l border-border bg-background shadow-2xl animate-slide-in-right max-sm:!w-full max-sm:max-w-none print:hidden"
      >
        <div
          onMouseDown={startResize}
          title={t("help.resize", "드래그하여 너비 조절")}
          className="absolute left-0 top-0 bottom-0 z-10 w-1.5 cursor-col-resize hover:bg-primary/40 max-sm:hidden"
        />
        <div className="flex items-center gap-2 border-b border-border px-4 py-3">
          <BookOpen className="h-5 w-5 text-primary" aria-hidden="true" />
          <h2 className="flex-1 text-sm font-bold text-text">{panelTitle}</h2>
          <button ref={closeRef} type="button" onClick={closeHelp} className="rounded p-1 hover:bg-surface" aria-label={t("common.close", "닫기")}>
            <X className="h-4 w-4 text-text-muted" />
          </button>
        </div>

        {tabs.length > 1 ? (
          <div className="flex border-b border-border" role="tablist">
            {tabs.map((item) => (
              <button
                key={item.key}
                type="button"
                role="tab"
                aria-selected={tab === item.key}
                onClick={() => setTab(item.key)}
                className={`flex-1 px-3 py-2 text-sm font-medium transition-colors ${
                  tab === item.key ? "border-b-2 border-primary text-primary" : "text-text-muted hover:text-text"
                }`}
              >
                {t(item.labelKey, item.fallback)}
              </button>
            ))}
          </div>
        ) : null}

        <div className="flex items-center gap-2 border-b border-border bg-surface/40 px-4 py-2">
          <label className="relative min-w-0 flex-1">
            <Search className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-text-muted" aria-hidden="true" />
            <input
              value={searchQuery}
              aria-label={t("help.searchInCurrentDoc", "현재 도움말에서 찾기")}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && searchMatchCount > 0) {
                  e.preventDefault();
                  setSearchIndex((prev) => (e.shiftKey ? prev - 1 + searchMatchCount : prev + 1) % searchMatchCount);
                }
              }}
              placeholder={t("help.searchInCurrentDoc", "현재 도움말에서 찾기")}
              className="h-8 w-full rounded border border-border bg-background pl-8 pr-2 text-sm text-text outline-none focus:border-primary"
            />
          </label>
          <span className="w-16 shrink-0 text-right text-xs text-text-muted">
            {searchQuery.trim().length >= MIN_SEARCH_LENGTH ? `${searchMatchCount === 0 ? 0 : searchIndex + 1}/${searchMatchCount}` : "-"}
          </span>
          <button
            type="button"
            onClick={() => setSearchIndex((prev) => (prev - 1 + searchMatchCount) % searchMatchCount)}
            disabled={searchMatchCount === 0}
            className="rounded border border-border p-1.5 text-text-muted hover:text-text disabled:cursor-not-allowed disabled:opacity-40"
            aria-label={t("help.previousMatch", "이전 찾기")}
          >
            <ChevronUp className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => setSearchIndex((prev) => (prev + 1) % searchMatchCount)}
            disabled={searchMatchCount === 0}
            className="rounded border border-border p-1.5 text-text-muted hover:text-text disabled:cursor-not-allowed disabled:opacity-40"
            aria-label={t("help.nextMatch", "다음 찾기")}
          >
            <ChevronDown className="h-4 w-4" />
          </button>
        </div>

        <div className="flex justify-end border-b border-border px-4 py-2">
          <HelpExportActions contentRef={contentRef} title={exportTitle} disabled={loading || notFound || !content} />
        </div>

        <div ref={contentRef} className="flex-1 overflow-y-auto px-4 py-3">
          {loading ? (
            <div className="flex h-full items-center justify-center">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            </div>
          ) : notFound || !content ? (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center text-text-muted">
              <BookOpen className="h-10 w-10 opacity-30" aria-hidden="true" />
              <p className="text-sm">{t("help.notReady", "이 화면의 도움말은 준비 중입니다.")}</p>
            </div>
          ) : (
            <MarkdownRenderer content={content} />
          )}
        </div>

        {helpPagePath ? (
          <div className="border-t border-border px-4 py-3">
            <button
              type="button"
              onClick={() => {
                closeHelp();
                navigateClientOnly(helpPagePath);
              }}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90"
            >
              <ExternalLink className="h-4 w-4" aria-hidden="true" />
              {t("help.viewAll", "전체 도움말 보기")}
            </button>
          </div>
        ) : null}
      </aside>
    </>
  );
}
