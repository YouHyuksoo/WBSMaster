/**
 * @file src/help/useHelpDoc.ts
 * @description 도움말 markdown·목차 읽기 훅. 현재 언어 문서가 없으면 ko 로 대신한다.
 */
"use client";

import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { defaultHelpDocPath, parseHelpDoc, type HelpDocPath, type HelpManifest, type HelpMeta, type HelpTab } from "./help";

/** 없는 파일에 Next 가 HTML(404 화면)을 돌려줄 때도 문서 없음으로 본다. */
function fetchDoc(path: string): Promise<string | null> {
  return fetch(path).then((res) => {
    if (!res.ok) return null;
    return res.text().then((text) => (text.trimStart().startsWith("<") ? null : text));
  });
}

export function useHelpDoc(docKey: string | undefined, tab: HelpTab, docPath: HelpDocPath = defaultHelpDocPath) {
  const { i18n } = useTranslation();
  const lang = i18n.language?.split("-")[0] || "ko";

  const [content, setContent] = useState<string | null>(null);
  const [meta, setMeta] = useState<HelpMeta | null>(null);
  const [loading, setLoading] = useState(false);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!docKey) {
      setContent(null);
      setMeta(null);
      setNotFound(true);
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setNotFound(false);

    void (async () => {
      try {
        const langs = lang === "ko" ? ["ko"] : [lang, "ko"];
        for (const l of langs) {
          const text = await fetchDoc(docPath(tab, docKey, l));
          if (cancelled) return;
          if (text) {
            const parsed = parseHelpDoc(text);
            setMeta(parsed.meta);
            setContent(parsed.body);
            return;
          }
        }
        setContent(null);
        setMeta(null);
        setNotFound(true);
      } catch {
        if (cancelled) return;
        setContent(null);
        setMeta(null);
        setNotFound(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [docKey, tab, lang, docPath]);

  return { meta, content, loading, notFound };
}

/** 도움말 목차(manifest.json) 읽기 */
export function useHelpManifest(url = "/help/manifest.json") {
  const [manifest, setManifest] = useState<HelpManifest | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    fetch(url)
      .then((res) => (res.ok ? res.json() : null))
      .then((data: HelpManifest | null) => {
        if (!cancelled) setManifest(data);
      })
      .catch(() => {
        if (!cancelled) setManifest(null);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [url]);

  return { manifest, loading };
}
