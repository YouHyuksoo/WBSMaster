"use client";

/**
 * @file common-codes/commonCodes.tsx
 * @description 공통코드 드롭다운·배지·이름 찾기. 코드는 제품이 어댑터(fetchCommonCodes)로 넘기고, 패키지는 한 번 읽어 저장소에 둔다.
 * (HANES useComCode·ComCodeSelect·ComCodeBadge 를 제품 중립으로 옮김. 이름은 코드마다 언어별 names 를 갖는다.)
 *
 * 쓰는 법:
 *   <JisungUIProvider adapters={{ fetchCommonCodes: () => api('/common-codes') }}>
 *   <CommonCodeSelect groupCode="CSR_KIND" label="요청유형" value={kind} onChange={setKind} />
 *   <CommonCodeBadge groupCode="CSR_STATUS" code={row.status} />
 *   const label = useCommonCodeLabel("CSR_KIND"); label("BUG")
 * 관리 화면에서 저장한 뒤 refreshCommonCodes() 로 다시 읽는다.
 */
import { useEffect, useMemo } from "react";
import { create } from "zustand";
import { useTranslation } from "react-i18next";
import { useUIAdapters } from "../provider/UIProvider";
import Select, { type SelectOption, type SelectProps } from "../ui/Select";
import Badge, { type BadgeVariant } from "../ui/Badge";

export type CommonCodeNames = Partial<Record<string, string>> & { ko: string };
export interface CommonCodeGroupItem {
  groupCode: string;
  names: CommonCodeNames;
  description?: string;
  system?: boolean;
  sortOrder: number;
}
export interface CommonCodeItem {
  groupCode: string;
  code: string;
  names: CommonCodeNames;
  description?: string;
  sortOrder: number;
  active: boolean;
  badge?: BadgeVariant | null;
}
export interface CommonCodeData {
  groups: CommonCodeGroupItem[];
  codes: CommonCodeItem[];
}

type Status = "idle" | "loading" | "ready" | "error";
interface CommonCodeState {
  data: CommonCodeData | null;
  status: Status;
  fetcher: (() => Promise<CommonCodeData>) | null;
  load: (fetcher: () => Promise<CommonCodeData>) => Promise<void>;
  reset: () => void;
}

export const useCommonCodeStore = create<CommonCodeState>()((set, get) => ({
  data: null,
  status: "idle",
  fetcher: null,
  load: async (fetcher) => {
    if (get().status === "loading") return;
    set({ status: "loading", fetcher });
    try {
      set({ data: await fetcher(), status: "ready" });
    } catch {
      set({ status: "error" });
    }
  },
  reset: () => set({ data: null, status: "idle", fetcher: null }),
}));

/** 관리 화면에서 저장한 뒤 다시 읽는다 */
export async function refreshCommonCodes() {
  const { fetcher, load } = useCommonCodeStore.getState();
  if (fetcher) await load(fetcher);
}
/** 로그아웃 등으로 계정이 바뀔 때 비운다(다음에 쓸 때 다시 읽는다) */
export function resetCommonCodes() {
  useCommonCodeStore.getState().reset();
}

/** 저장소를 채운다(처음 쓰는 곳에서 한 번). 어댑터가 없으면 빈 목록이다. */
export function useCommonCodeData() {
  const { fetchCommonCodes } = useUIAdapters();
  const data = useCommonCodeStore((s) => s.data);
  const status = useCommonCodeStore((s) => s.status);
  useEffect(() => {
    if (fetchCommonCodes && useCommonCodeStore.getState().status === "idle") void useCommonCodeStore.getState().load(fetchCommonCodes);
  }, [fetchCommonCodes]);
  return { data, status };
}

/** 현재 언어 이름 → 한국어 이름 → 코드 */
export function commonCodeName(names: CommonCodeNames | undefined, language: string, fallback: string) {
  const lang = language.toLowerCase().split("-")[0];
  return names?.[lang] || names?.ko || fallback;
}

const byOrder = (a: { sortOrder: number; code?: string }, b: { sortOrder: number; code?: string }) =>
  a.sortOrder - b.sortOrder || (a.code ?? "").localeCompare(b.code ?? "");

/** 묶음의 코드(사용 안 함 포함) — 순서대로 */
export function useCommonCodes(groupCode: string): CommonCodeItem[] {
  const { data } = useCommonCodeData();
  return useMemo(() => (data?.codes ?? []).filter((c) => c.groupCode === groupCode).sort(byOrder), [data, groupCode]);
}

/** 코드 → 현재 언어 이름. 모르는 코드는 코드 그대로. */
export function useCommonCodeLabel(groupCode: string): (code: string | null | undefined) => string {
  const codes = useCommonCodes(groupCode);
  const { i18n } = useTranslation();
  return useMemo(() => {
    const map = new Map(codes.map((c) => [c.code, c]));
    return (code) => (code ? commonCodeName(map.get(code)?.names, i18n.language, code) : "");
  }, [codes, i18n.language]);
}

/** 묶음 이름(현재 언어) */
export function useCommonCodeGroupLabel(groupCode: string): string {
  const { data } = useCommonCodeData();
  const { i18n } = useTranslation();
  return commonCodeName(data?.groups.find((g) => g.groupCode === groupCode)?.names, i18n.language, groupCode);
}

export interface CommonCodeOptionsConfig {
  /** 맨 앞에 '전체'(빈 값) 항목. 문자열이면 그 이름으로 */
  includeAll?: boolean | string;
  /** 지금 값. 사용 안 함 코드여도 목록에 남겨 "(사용 안 함)" 을 붙인다(예전 자료 수정) */
  current?: string | null;
  /** 보일 코드만 고른다(예: 관제 등록은 OS 의 UNKNOWN 제외) */
  filter?: (code: CommonCodeItem) => boolean;
}

/** 드롭다운 항목: 사용 중인 코드 + (사용 안 함이어도) 지금 값 */
export function useCommonCodeOptions(groupCode: string, config: CommonCodeOptionsConfig = {}): SelectOption[] {
  const codes = useCommonCodes(groupCode);
  const { t, i18n } = useTranslation();
  const { includeAll, current, filter } = config;
  return useMemo(() => {
    const options = codes
      .filter((c) => (c.active || c.code === current) && (!filter || filter(c) || c.code === current))
      .map((c) => {
        const name = commonCodeName(c.names, i18n.language, c.code);
        return { value: c.code, label: c.active ? name : `${name} (${t("commonCodes.inactive")})` };
      });
    if (current && !options.some((o) => o.value === current)) options.push({ value: current, label: current });
    if (includeAll) options.unshift({ value: "", label: typeof includeAll === "string" ? includeAll : t("commonCodes.all") });
    return options;
  }, [codes, current, filter, includeAll, i18n.language, t]);
}

export type CommonCodeSelectProps = Omit<SelectProps, "options"> & { groupCode: string } & Omit<CommonCodeOptionsConfig, "current">;

/** 공통코드 드롭다운(Select). 지금 값(value)이 사용 안 함 코드여도 보인다. */
export function CommonCodeSelect({ groupCode, includeAll, filter, value, ...props }: CommonCodeSelectProps) {
  const options = useCommonCodeOptions(groupCode, {
    includeAll,
    filter,
    current: value === undefined || value === "" ? null : String(value),
  });
  return <Select {...props} value={value} options={options} />;
}

export interface CommonCodeBadgeProps {
  groupCode: string;
  code: string | null | undefined;
  /** 코드에 색이 없을 때 */
  fallbackVariant?: BadgeVariant;
  className?: string;
}

/** 공통코드 배지: 이름은 현재 언어, 색은 코드의 badge */
export function CommonCodeBadge({ groupCode, code, fallbackVariant = "neutral", className }: CommonCodeBadgeProps) {
  const codes = useCommonCodes(groupCode);
  const { i18n } = useTranslation();
  if (!code) return null;
  const found = codes.find((c) => c.code === code);
  return (
    <Badge variant={found?.badge ?? fallbackVariant} className={className}>
      {commonCodeName(found?.names, i18n.language, code)}
    </Badge>
  );
}
