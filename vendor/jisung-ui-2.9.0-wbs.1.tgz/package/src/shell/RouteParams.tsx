"use client";

/**
 * @file shell/RouteParams.tsx
 * @description keep-alive 탭 안의 동적 경로 페이지(`/csr/[id]`)가 자기 탭의 params 를 읽게 한다.
 * 탭 페이지는 Next 라우터가 아니라 AppShell 이 직접 렌더하므로 next/navigation 의 useParams() 는
 * 현재 URL 기준이라 숨은 탭에서 틀린 값을 준다. 화면은 useRouteParams() 를 쓴다.
 */
import { createContext, useContext, type ReactNode } from "react";
import { useParams } from "next/navigation";

export type RouteParams = Record<string, string | string[]>;

const RouteParamsContext = createContext<RouteParams | null>(null);

/** 페이지 레지스트리 생성기가 동적 경로 페이지를 감쌀 때 쓴다 */
export function RouteParamsProvider({ params, children }: { params: RouteParams; children: ReactNode }) {
  return <RouteParamsContext.Provider value={params}>{children}</RouteParamsContext.Provider>;
}

/** 탭 안에서는 그 탭 경로의 params, 탭 밖(Next 가 직접 렌더한 화면)에서는 Next useParams() */
export function useRouteParams<T extends RouteParams = RouteParams>(): Partial<T> {
  const fromTab = useContext(RouteParamsContext);
  const fromNext = useParams();
  return (fromTab ?? fromNext ?? {}) as Partial<T>;
}
