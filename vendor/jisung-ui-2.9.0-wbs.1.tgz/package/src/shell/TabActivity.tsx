"use client";

/**
 * @file shell/TabActivity.tsx
 * @description keep-alive 탭 안의 화면이 지금 보이는지, 다시 보이게 됐는지 알려준다.
 * 탭 화면은 숨어도 상태가 남아 있어서, 다른 탭에서 바뀐 자료가 돌아왔을 때 반영되지 않는다.
 * 목록처럼 최신이어야 하는 화면은 useOnTabReactivate 로 다시 읽는다.
 */
import { createContext, useContext, useEffect, useRef, type ReactNode } from "react";

const TabActiveContext = createContext(true);

export function TabActivityProvider({ active, children }: { active: boolean; children: ReactNode }) {
  return <TabActiveContext.Provider value={active}>{children}</TabActiveContext.Provider>;
}

/** 이 화면의 탭이 지금 보이는지. 탭 밖(keep-alive 아님)에서는 항상 true. */
export function useIsTabActive(): boolean {
  return useContext(TabActiveContext);
}

/** 탭이 숨었다가 다시 보일 때 callback 을 부른다. 처음 마운트할 때는 부르지 않는다. */
export function useOnTabReactivate(callback: () => void) {
  const active = useIsTabActive();
  const wasActive = useRef(active);
  const latest = useRef(callback);
  latest.current = callback;
  useEffect(() => {
    if (active && !wasActive.current) latest.current();
    wasActive.current = active;
  }, [active]);
}
