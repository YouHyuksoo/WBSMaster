/**
 * @file shell/types.ts
 * @description 앱 틀(AppShell)이 제품에게서 받는 설정의 형태.
 * 메뉴 데이터·즐겨찾기 저장·제품 전용 표시는 제품이 넘기고, 틀의 모양과 동작은 패키지가 고정한다.
 */
import type { ComponentType, ReactNode } from "react";

export interface MenuNode {
  /** 권한 체크용 고유 코드 (대문자_언더스코어) */
  code: string;
  /** i18n 번역 키 */
  labelKey: string;
  /** 라우트 경로 (하위 메뉴가 있으면 생략) */
  path?: string;
  /** 아이콘 (최상위 메뉴만 사용) */
  icon?: ComponentType<{ className?: string }>;
  children?: MenuNode[];
}

/** 로그인 사용자에게 보여줄 메뉴 트리와 권한 판별 */
export interface MenuSource {
  items: MenuNode[];
  /** true 면 흐리게(opacity-40) 표시하고 이동을 막는다. 숨기지 않는다. */
  isMenuDisabled: (item: MenuNode) => boolean;
}

export interface FavoritesApi {
  favorites: string[];
  isFavorite: (menuCode: string) => boolean;
  toggleFavorite: (menuCode: string) => void;
}

export interface FavoriteFolder {
  id: number;
  name: string;
  sortOrder: number;
}

export type FavoriteFolderAction =
  | { type: "create"; name: string }
  | { type: "rename"; id: number; name: string }
  | { type: "delete"; id: number }
  | { type: "move"; menuCode: string; folderId: number | null };

export interface FavoriteFoldersApi {
  folders: FavoriteFolder[];
  assignments: { menuCode: string; folderId: number | null }[];
  loading: boolean;
  error: boolean;
  reload: () => unknown;
  save: (action: FavoriteFolderAction) => Promise<unknown>;
  saving: boolean;
}

export interface ShellLanguage {
  code: string;
  name: string;
  flag: string;
}

/** 사이드바 하단 고정 영역에 둘 최상위 메뉴 코드와 접근성 라벨 키 */
export interface SidebarSection {
  codes: readonly string[];
  labelKeys: readonly string[];
}

export interface AppShellConfig {
  /** 로고 글자와 제품명. HANES: { mark: "H", name: "HARNESS MES" } */
  brand: { mark: string; name: string };
  /** 정적 메뉴 트리. 현재 경로로 탭을 만들고 탭 아이콘을 찾을 때 쓴다. */
  menuConfig: MenuNode[];
  /** 로그인 사용자 기준 메뉴 트리(권한·DB 정렬 반영) — React 훅 */
  useMenu: () => MenuSource;
  /** 즐겨찾기 목록과 토글 — React 훅 */
  useFavorites: () => FavoritesApi;
  /** 즐겨찾기 폴더 — React 훅 */
  useFavoriteFolders: () => FavoriteFoldersApi;
  /** 최대 탭 수 — React 훅 */
  useMaxTabs: () => number;
  /** 탭 keep-alive 용 경로 → 페이지 컴포넌트 */
  getPageComponent: (path: string) => Promise<ComponentType | null>;
  /** 사이드바: 업무 메뉴 아래 고정 영역(pinned)과 관리자 영역(admin) */
  sidebarSections: { pinned: SidebarSection; admin: SidebarSection };
  /** 처음 펼쳐 둘 그룹 코드. 나머지 그룹은 접힌 채 시작한다. */
  defaultExpandedCodes: readonly string[];
  /** 사이드바 맨 아래 도움말 링크 */
  helpMenu?: MenuNode;
  /** 언어 전환 목록과 선택 저장 키 */
  languages: readonly ShellLanguage[];
  languageStorageKey: string;
  user: { name?: string | null; email?: string | null } | null;
  onLogout: () => void;
  /** 상단바 오른쪽, 팔레트 앞에 붙는 제품 전용 표시(스캐너·프린트 에이전트 등) */
  headerIndicators?: ReactNode;
  /** 언어 전환 뒤의 도움말 버튼 */
  helpButton?: ReactNode;
  /** 도움말 뒤, 사용자 메뉴 앞의 범위 표시(회사/사업장, 고객사, 접속 DB 등) */
  scopeBadge?: ReactNode;
  /** 사용자 메뉴의 제품 항목. 로그아웃은 패키지가 마지막에 붙인다. close 로 메뉴를 닫는다. */
  userMenuItems?: (close: () => void) => ReactNode;
  /** 화면 위에 떠 있는 제품 기능(연결확인, AI 채팅, 도움말 패널 등) */
  overlays?: ReactNode;
  /** 헤더·사이드바·탭 없이 본문만(키오스크, view=full) */
  chromeless?: boolean;
  /** 작은 화면에서 사이드바 맨 위에 두는 칸(예: 고객사 선택). 큰 화면에서는 숨는다. */
  sidebarTop?: ReactNode;
  /** 현재 경로를 볼 수 있는지. false 면 화면 대신 accessDenied 를 보여준다(서버 권한 검사는 별도). */
  canAccessPath?: (path: string) => boolean;
  accessDenied?: ReactNode;
  /** 모든 탭 페이지를 감쌀 틀(예: 공통 여백·스크롤). 없으면 페이지를 그대로 그린다. */
  pageFrame?: ComponentType<{ children: ReactNode }>;
  /**
   * 메뉴에 없는 경로의 탭 이름(경로 → i18n 키). 예: { "/csr/new": "csr.create.title" }.
   * 없으면 가장 가까운 상위 메뉴 이름 + 마지막 세그먼트("고객 요청 · CSR · 1024")다.
   */
  tabLabels?: Record<string, string>;
  /**
   * true 면 메뉴에 없는 상세 경로(/customers/123)를 새 탭이 아니라 상위 메뉴 탭 안에서 연다.
   * 목록으로 돌아가면 같은 탭이 다시 목록이 되고, 목록 화면 상태(검색·선택)는 그대로 남는다. 기본은 false(상세마다 새 탭).
   */
  detailInParentTab?: boolean;
}
