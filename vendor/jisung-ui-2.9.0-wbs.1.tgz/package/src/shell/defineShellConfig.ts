/**
 * @file shell/defineShellConfig.ts
 * @description AppShellConfig 를 필수 항목만으로 만든다. 나머지는 표준값으로 채운다.
 *
 * 필수: brand, menuConfig, getPageComponent, useFavorites, useFavoriteFolders, user, onLogout
 * 표준값: 메뉴는 전부 허용(useMenu), 최대 탭 10, 사이드바 고정·관리자 영역 없음, 첫 메뉴 그룹만 펼침,
 *        4개 언어(ko/en/zh/vi, UI_LANGUAGES 에는 es 도 있음), 언어 저장 키 "i18nextLng"
 */
import { DEFAULT_MAX_TABS } from "./tabStore";
import type { AppShellConfig, ShellLanguage } from "./types";

/** 표준 지원 언어 (원본: HANES supportedLanguages) */
export const DEFAULT_LANGUAGES: readonly ShellLanguage[] = [
  { code: "ko", name: "한국어", flag: "🇰🇷" },
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "zh", name: "中文", flag: "🇨🇳" },
  { code: "vi", name: "Tiếng Việt", flag: "🇻🇳" },
];

/** 패키지가 문구를 가진 모든 언어. 제품은 여기서 필요한 언어만 골라 languages 로 넘긴다(DEFAULT_LANGUAGES 는 그대로 4개). */
export const UI_LANGUAGES: readonly ShellLanguage[] = [...DEFAULT_LANGUAGES, { code: "es", name: "Español", flag: "🇪🇸" }];

type Required = "brand" | "menuConfig" | "getPageComponent" | "useFavorites" | "useFavoriteFolders" | "user" | "onLogout";

export type ShellConfigInput = Pick<AppShellConfig, Required> & Partial<Omit<AppShellConfig, Required>>;

export function defineShellConfig(input: ShellConfigInput): AppShellConfig {
  const { menuConfig } = input;
  return {
    useMenu: () => ({ items: menuConfig, isMenuDisabled: () => false }),
    useMaxTabs: () => DEFAULT_MAX_TABS,
    sidebarSections: { pinned: { codes: [], labelKeys: [] }, admin: { codes: [], labelKeys: [] } },
    defaultExpandedCodes: menuConfig.length ? [menuConfig[0].code] : [],
    languages: DEFAULT_LANGUAGES,
    languageStorageKey: "i18nextLng",
    ...input,
  };
}
