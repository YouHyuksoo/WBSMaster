"use client";

/**
 * @file src/components/layout/SidebarMenu.tsx
 * @description 사이드바 메뉴 렌더링 - RBAC 권한 기반 활성/비활성 처리
 *
 * 초보자 가이드:
 * 1. **펼친 상태**: 아이콘 + 텍스트 + 하위메뉴 토글
 * 2. **접힌 상태**: 아이콘만 표시, 호버 시 툴팁으로 메뉴명 확인
 * 3. **비활성 메뉴**: opacity-40 + cursor-not-allowed, 클릭 무시
 * 4. **부모 메뉴**: 하위 중 하나라도 허용이면 펼침 가능
 */
import { ChevronDown, ChevronRight, Star } from "lucide-react";
import type { MenuNode as MenuConfigItem } from "./types";
import { useTabStore } from "./tabStore";
import { navigateClientOnly } from "./clientNavigation";

interface SidebarMenuProps {
  items: MenuConfigItem[];
  collapsed: boolean;
  pathname: string;
  expandedMenus: string[];
  onToggleMenu: (code: string) => void;
  isMenuActive: (item: MenuConfigItem) => boolean | undefined;
  /** 메뉴 항목이 비활성(권한 없음)인지 판별하는 함수 */
  isMenuDisabled: (item: MenuConfigItem) => boolean;
  onClose?: () => void;
  t: (key: string) => string;
  /** 즐겨찾기 여부 판별 (미전달 시 별 토글 미표시) */
  isFavorite?: (menuCode: string) => boolean;
  /** 즐겨찾기 토글 핸들러 (미전달 시 별 토글 미표시) */
  onToggleFavorite?: (menuCode: string) => void;
  onMenuDragStart?: (menuCode: string) => void;
}

export default function SidebarMenu({
  items, collapsed, pathname, expandedMenus, onToggleMenu, isMenuActive, isMenuDisabled, onClose, t,
  isFavorite, onToggleFavorite, onMenuDragStart,
}: SidebarMenuProps) {
  const addTab = useTabStore((s) => s.addTab);

  /** leaf 우측 별(★) 토글 — 버튼 안 중첩 버튼 금지라 span으로 렌더 */
  const renderFavoriteToggle = (menuCode: string) => {
    if (collapsed || !onToggleFavorite) return null;
    const favorited = isFavorite?.(menuCode) ?? false;
    return (
      <span
        role="button"
        tabIndex={-1}
        title={favorited ? t("menu.favorites.remove") : t("menu.favorites.add")}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onToggleFavorite(menuCode);
        }}
        className={`flex-shrink-0 transition-opacity ${favorited ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`}
      >
        <Star className={`w-3.5 h-3.5 ${favorited ? "fill-amber-400 text-amber-400" : ""}`} />
      </span>
    );
  };

  const handleMenuClick = (
    e: React.MouseEvent,
    menuItem: { code: string; path: string; labelKey: string },
    parentCode: string
  ) => {
    const opened = addTab({ id: menuItem.code, path: menuItem.path, labelKey: menuItem.labelKey, parentId: parentCode });
    // 최대 탭 수 초과로 차단되면 페이지 이동도 막는다 (안내 모달은 TabBar에서 표시)
    if (!opened) {
      e.preventDefault();
      return;
    }
    navigateClientOnly(menuItem.path);
    onClose?.();
  };

  /** 비활성 메뉴에 적용할 클래스 */
  const disabledCls = "opacity-40 cursor-not-allowed";

  return (
    <ul className="space-y-0.5">
      {items.map((item) => {
        const disabled = isMenuDisabled(item);

        return (
          <li key={item.code}>
            {/* 단일 메뉴 (하위 없음) */}
            {item.path && !item.children ? (
              disabled ? (
                <span
                  title={collapsed ? t(item.labelKey) : undefined}
                  className={`
                    flex items-center gap-3 py-1.5 rounded-[var(--radius)]
                    text-sm font-medium select-none ${disabledCls}
                    ${collapsed ? "justify-center px-0" : "px-3"}
                    text-text
                  `}
                >
                  {item.icon && <item.icon className="w-5 h-5 flex-shrink-0" />}
                  {!collapsed && <span className="truncate">{t(item.labelKey)}</span>}
                </span>
              ) : (
                <button
                  type="button"
                  draggable={!!onMenuDragStart}
                  onDragStart={(e) => { e.dataTransfer.setData('text/hanes-menu-code', item.code); e.dataTransfer.effectAllowed = 'move'; onMenuDragStart?.(item.code); }}
                  onClick={(e) => handleMenuClick(e, item as { code: string; path: string; labelKey: string }, item.code)}
                  aria-current={pathname === item.path ? "page" : undefined}
                  title={collapsed ? t(item.labelKey) : undefined}
                  className={`
                    group flex w-full items-center gap-3 py-1.5 rounded-[var(--radius)]
                    text-sm font-medium transition-colors duration-200
                    ${collapsed ? "justify-center px-0" : "px-3"}
                    ${pathname === item.path ? "bg-primary text-white" : "text-text hover:bg-background"}
                  `}
                >
                  {item.icon && <item.icon className="w-5 h-5 flex-shrink-0" />}
                  {!collapsed && <span className="flex-1 truncate text-left">{t(item.labelKey)}</span>}
                  {renderFavoriteToggle(item.code)}
                </button>
              )
            ) : (
              /* 하위 메뉴가 있는 경우 */
              <>
                <button
                  onClick={() => !disabled && onToggleMenu(item.code)}
                  aria-expanded={expandedMenus.includes(item.code)}
                  title={collapsed ? t(item.labelKey) : undefined}
                  className={`
                    w-full flex items-center py-1.5 rounded-[var(--radius)]
                    text-sm font-medium transition-colors duration-200
                    ${collapsed ? "justify-center px-0" : "justify-between px-3"}
                    ${disabled ? disabledCls : ""}
                    ${!disabled && isMenuActive(item) ? "bg-primary/10 text-primary" : "text-text hover:bg-background"}
                  `}
                >
                  <div className="flex items-center gap-3">
                    {item.icon && <item.icon className="w-5 h-5 flex-shrink-0" />}
                    {!collapsed && <span className="truncate">{t(item.labelKey)}</span>}
                  </div>
                  {!collapsed && !disabled && (
                    expandedMenus.includes(item.code)
                      ? <ChevronDown className="w-4 h-4 flex-shrink-0" />
                      : <ChevronRight className="w-4 h-4 flex-shrink-0" />
                  )}
                </button>

                {/* 하위 메뉴 리스트 (펼친 상태에서만) */}
                {!collapsed && expandedMenus.includes(item.code) && item.children && (
                  <ul className="mt-0.5 ml-4 pl-4 border-l border-border space-y-0">
                    {item.children.map((child) => {
                      const childDisabled = isMenuDisabled(child);
                      return (
                        <li key={child.code}>
                          {childDisabled ? (
                            <span
                              className={`block px-3 py-2 rounded-[var(--radius)] text-sm select-none ${disabledCls} text-text-muted`}
                            >
                              {t(child.labelKey)}
                            </span>
                          ) : (
                            <button
                              type="button"
                              draggable={!!onMenuDragStart}
                              onDragStart={(e) => { e.dataTransfer.setData('text/hanes-menu-code', child.code); e.dataTransfer.effectAllowed = 'move'; onMenuDragStart?.(child.code); }}
                              onClick={(e) => handleMenuClick(e, child as { code: string; path: string; labelKey: string }, item.code)}
                              aria-current={pathname === child.path ? "page" : undefined}
                              className={`
                                group flex w-full items-center gap-2 px-3 py-2 rounded-[var(--radius)] text-left text-sm transition-colors duration-200
                                ${pathname === child.path
                                  ? "bg-primary text-white"
                                  : "text-text-muted hover:text-text hover:bg-background"
                                }
                              `}
                            >
                              <span className="flex-1 truncate">{t(child.labelKey)}</span>
                              {renderFavoriteToggle(child.code)}
                            </button>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                )}
              </>
            )}
          </li>
        );
      })}
    </ul>
  );
}
