/**
 * @file src/hooks/useTabSync.ts
 * @description URL 변경 시 활성 탭을 동기화하는 훅
 *
 * 초보자 가이드:
 * 1. **usePathname()**: Next.js App Router에서 현재 URL 경로를 반환
 * 2. **syncActiveTabByPath**: 경로에 해당하는 탭을 활성 상태로 변경
 * 3. 경로에 해당하는 탭이 없으면(새로고침·딥링크 직접 진입) 메뉴 설정에서 찾아 탭을 자동 등록
 *    — 탭 목록은 비영속이라 재진입 시 초기화되므로, 현재 페이지만 첫 탭으로 복원된다
 * 4. MainLayout에서 한 번만 호출하면 전체 앱에서 동기화 처리됨
 */
import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { useTabStore } from "./tabStore";
import { findMenuItemByPath, useShellConfig } from "./ShellContext";
import type { MenuNode } from "./types";

/**
 * 메뉴에 없는 상세 경로(/csr/1024)는 가장 가까운 상위 메뉴 경로(/csr)를 찾는다.
 * 경로마다 탭을 따로 열고, 탭 이름은 상위 메뉴 이름 + 마지막 세그먼트다.
 */
function findNearestMenuItem(menu: MenuNode[], pathname: string) {
  let path = pathname;
  while (path.lastIndexOf("/") > 0) {
    path = path.slice(0, path.lastIndexOf("/"));
    const found = findMenuItemByPath(menu, path);
    if (found) return found;
  }
  return undefined;
}

export function useTabSync() {
  const pathname = usePathname();
  const { menuConfig, tabLabels, detailInParentTab } = useShellConfig();

  useEffect(() => {
    const { tabs, addTab, syncActiveTabByPath, setTabPath } = useTabStore.getState();
    const matched = tabs.find((t) => t.path === pathname);
    if (matched) {
      syncActiveTabByPath(pathname);
      return;
    }
    const found = findMenuItemByPath(menuConfig, pathname);
    if (found && found.item.path) {
      // 같은 탭에서 상세를 보다가 목록으로 돌아온 경우: 그 탭을 다시 목록으로
      const own = detailInParentTab ? tabs.find((t) => t.id === found.item.code) : undefined;
      if (own) {
        setTabPath(own.id, pathname);
        return;
      }
      addTab({
        id: found.item.code,
        path: found.item.path,
        labelKey: found.item.labelKey,
        parentId: found.parentCode,
      });
      return;
    }
    const parent = findNearestMenuItem(menuConfig, pathname);
    if (parent && detailInParentTab && parent.item.path) {
      // 상세는 상위 메뉴 탭 안에서 연다(새 탭 없음)
      const own = tabs.find((t) => t.id === parent.item.code);
      if (own) setTabPath(own.id, pathname);
      else
        addTab({
          id: parent.item.code,
          path: pathname,
          basePath: parent.item.path,
          labelKey: parent.item.labelKey,
          parentId: parent.parentCode,
        });
      return;
    }
    if (parent) {
      // 제품이 이름을 정한 경로(등록 화면 등)는 그 이름만, 아니면 상위 메뉴 이름 + 마지막 세그먼트
      const own = tabLabels?.[pathname];
      addTab({
        id: pathname,
        path: pathname,
        labelKey: own ?? parent.item.labelKey,
        parentId: parent.parentCode,
        ...(own ? {} : { suffix: decodeURIComponent(pathname.slice(pathname.lastIndexOf("/") + 1)) }),
      });
    }
  }, [pathname, menuConfig, tabLabels, detailInParentTab]);
}
