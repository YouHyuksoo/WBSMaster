"use client";

/**
 * @file shell/Header.tsx
 * @description 상단 헤더. 순서는 표준으로 고정한다.
 * 왼쪽: 모바일 메뉴 → 로고 → 사이드바 접기 / 가운데: 즐겨찾기 → 메뉴 검색
 * 오른쪽: 제품 표시(headerIndicators) → 팔레트 → 다크 → 언어 → 도움말(helpButton) → 범위(scopeBadge) → 사용자 메뉴
 */
import { useState, useRef, useEffect, useCallback, type ComponentType, type ReactNode } from "react";
import { useTranslation } from "react-i18next";
import { Sun, Moon, User, LogOut, Menu, PanelLeftClose, PanelLeftOpen, Palette } from "lucide-react";
import { useTheme } from "./useTheme";
import { useThemeStore, type ColorTheme } from "./themeStore";
import { useShellConfig } from "./ShellContext";
import LanguageSwitcher from "./LanguageSwitcher";
import HeaderMenuSearch from "./HeaderMenuSearch";
import FavoriteMenuDropdown from "./FavoriteMenuDropdown";

interface HeaderProps {
  onMenuToggle?: () => void;
  collapsed?: boolean;
  onToggleCollapse?: () => void;
}

const COLOR_THEME_ORDER: ColorTheme[] = ["default", "custom", "orchid"];

const COLOR_THEME_LABELS: Record<ColorTheme, string> = {
  default: "Default",
  custom: "Custom",
  orchid: "Orchid",
};

const MENU_ITEM_CLASS = `
                    w-full px-4 py-2 text-left text-sm
                    text-text hover:bg-background
                    flex items-center gap-2
                    focus:outline-none focus-visible:bg-background
                  `;

/** 사용자 메뉴 항목. 제품이 userMenuItems 에서 같은 모양으로 항목을 만들 때 쓴다. */
export function HeaderMenuItem({ icon: Icon, onClick, children }: { icon: ComponentType<{ className?: string }>; onClick?: () => void; children: ReactNode }) {
  return (
    <button role="menuitem" onClick={onClick} className={MENU_ITEM_CLASS}>
      <Icon className="w-4 h-4" />
      {children}
    </button>
  );
}

function Header({ onMenuToggle, collapsed, onToggleCollapse }: HeaderProps) {
  const { t } = useTranslation();
  const { isDark, toggleTheme } = useTheme();
  const { colorTheme, setColorTheme } = useThemeStore();
  const { brand, user, onLogout, headerIndicators, helpButton, scopeBadge, userMenuItems } = useShellConfig();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const currentColorThemeIndex = COLOR_THEME_ORDER.indexOf(colorTheme);
  const nextColorTheme =
    COLOR_THEME_ORDER[
      (currentColorThemeIndex >= 0 ? currentColorThemeIndex + 1 : 1) %
        COLOR_THEME_ORDER.length
    ];
  const colorThemeLabel = COLOR_THEME_LABELS[colorTheme] ?? COLOR_THEME_LABELS.default;

  const closeMenu = useCallback(() => setShowUserMenu(false), []);

  /* Escape 키 및 외부 클릭 처리 */
  useEffect(() => {
    if (!showUserMenu) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeMenu();
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [showUserMenu, closeMenu]);

  const handleLogout = () => {
    setShowUserMenu(false);
    onLogout();
  };

  return (
    <header
      className="
        fixed top-0 left-0 right-0 z-40 print:hidden
        h-[var(--header-height)]
        bg-surface border-b border-border
        flex items-center justify-between
        px-4
      "
    >
      {/* Left Section - Logo & Menu Toggle */}
      <div className="flex items-center gap-3">
        {/* Mobile Menu Toggle */}
        <button
          onClick={onMenuToggle}
          className="p-2 rounded-md lg:hidden hover:bg-background transition-colors"
          aria-label={t('header.openMenu')}
        >
          <Menu className="w-5 h-5 text-text" />
        </button>

        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <span className="text-white font-bold text-sm">{brand.mark}</span>
          </div>
          <span className="font-semibold text-lg text-text hidden sm:block">
            {brand.name}
          </span>
        </div>

        {/* 사이드바 접기/펴기 (데스크톱) */}
        {onToggleCollapse && (
          <button
            onClick={onToggleCollapse}
            className="hidden lg:flex p-2 rounded-md hover:bg-background transition-colors"
            aria-label={collapsed ? t('header.expandSidebar') : t('header.collapseSidebar')}
          >
            {collapsed
              ? <PanelLeftOpen className="w-5 h-5 text-text-muted" />
              : <PanelLeftClose className="w-5 h-5 text-text-muted" />
            }
          </button>
        )}
      </div>

      {/* Center Section - 즐겨찾기 드롭다운 + Search (즐겨찾기는 사이드바에서 헤더로 옮김, 2026-09-20) */}
      <div className="hidden md:flex flex-1 items-center gap-2 max-w-xl mx-8">
        <FavoriteMenuDropdown />
        <div className="min-w-0 flex-1"><HeaderMenuSearch /></div>
      </div>

      {/* Right Section - Actions */}
      <div className="flex items-center gap-2">
        {/* 제품 전용 표시 (HANES: 바코드 스캐너, 라벨 프린트 에이전트 / JSOverLoad: 알림) */}
        {headerIndicators}

        {/* 컬러 테마 토글 */}
        <button
          onClick={() => setColorTheme(nextColorTheme)}
          className="relative p-2 rounded-md hover:bg-background transition-colors"
          aria-label={`${t('header.colorTheme')}: ${colorThemeLabel}`}
          title={`${t('header.colorTheme')}: ${colorThemeLabel}`}
        >
          <Palette className={`w-5 h-5 ${colorTheme !== "default" ? "text-primary" : "text-text-muted"}`} />
          {colorTheme !== "default" && (
            <span
              className={`absolute right-1.5 top-1.5 h-2 w-2 rounded-full border border-surface ${
                colorTheme === "orchid" ? "bg-violet-400" : "bg-primary"
              }`}
              aria-hidden="true"
            />
          )}
        </button>

        {/* 테마 토글 */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-md hover:bg-background transition-colors"
          aria-label={isDark ? t('header.switchToLight') : t('header.switchToDark')}
        >
          {isDark ? (
            <Sun className="w-5 h-5 text-accent" />
          ) : (
            <Moon className="w-5 h-5 text-text-muted" />
          )}
        </button>

        {/* 언어 전환 */}
        <LanguageSwitcher />

        {/* 도움말 */}
        {helpButton}

        {/* 범위 표시 (HANES: 회사/사업장·접속 DB / JSOverLoad: 고객사) */}
        {scopeBadge}

        {/* 사용자 메뉴 */}
        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            aria-haspopup="menu"
            aria-expanded={showUserMenu}
            className="
              flex items-center gap-2 p-2
              rounded-md hover:bg-background transition-colors
            "
          >
            <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-primary" />
            </div>
            <span className="hidden sm:block text-sm font-medium text-text">
              {user?.name || user?.email || t('common.user')}
            </span>
          </button>

          {/* Dropdown Menu */}
          {showUserMenu && (
            <>
              <div
                className="fixed inset-0 z-10"
                aria-hidden="true"
                onClick={closeMenu}
              />
              <div
                role="menu"
                aria-label={t('header.profile')}
                className="
                  absolute right-0 top-full mt-2 z-20
                  w-48 py-1
                  bg-surface border border-border rounded-[var(--radius)]
                  shadow-lg animate-slide-down
                "
              >
                {userMenuItems && (
                  <>
                    {userMenuItems(closeMenu)}
                    <hr className="my-1 border-border" role="separator" />
                  </>
                )}
                <button
                  role="menuitem"
                  onClick={handleLogout}
                  className="
                    w-full px-4 py-2 text-left text-sm
                    text-error hover:bg-background
                    flex items-center gap-2
                    focus:outline-none focus-visible:bg-background
                  "
                >
                  <LogOut className="w-4 h-4" />
                  {t('header.logout')}
                </button>
              </div>
            </>
          )}
        </div>
      </div>

    </header>
  );
}

export default Header;
