"use client";
/**
 * @file shell/Sidebar.tsx
 * @description 사이드바 네비게이션. 세 영역으로 나눈다.
 * 1. 업무 메뉴(스크롤) 2. 고정 영역(sidebarSections.pinned) 3. 관리자 영역(sidebarSections.admin) + 맨 아래 도움말
 * 메뉴 트리·권한·즐겨찾기는 제품이 AppShell 설정으로 넘긴다.
 */
import { useMemo, useState } from "react";
import { usePathname } from "next/navigation";
import { useTranslation } from "react-i18next";
import type { MenuNode as MenuConfigItem } from "./types";
import { useShellConfig } from "./ShellContext";
import SidebarMenu from "./SidebarMenu";

/** 현재 화면 메뉴 경로. 메뉴에 없는 상세 경로(/csr/1024)는 가장 가까운 상위 메뉴 경로(/csr)로 본다. */
function nearestMenuPath(items: MenuConfigItem[], pathname: string): string {
  const paths = items.flatMap((item) => (item.children ?? [item]).map((child) => child.path ?? ""));
  if (paths.includes(pathname)) return pathname;
  return paths.filter((p) => p && p !== "/" && pathname.startsWith(p + "/")).sort((a, b) => b.length - a.length)[0] ?? pathname;
}

interface SidebarProps {
  isOpen: boolean;
  onClose?: () => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

function Sidebar({ isOpen, onClose, collapsed }: SidebarProps) {
  const { t } = useTranslation();
  const rawPathname = usePathname();
  const { useMenu, useFavorites, sidebarSections, defaultExpandedCodes, helpMenu, sidebarTop } = useShellConfig();
  const { items, isMenuDisabled } = useMenu();
  const pathname = useMemo(
    () => nearestMenuPath(helpMenu ? [...items, helpMenu] : items, rawPathname),
    [items, helpMenu, rawPathname],
  );
  // 즐겨찾기 목록 표시는 헤더 드롭다운(FavoriteMenuDropdown)으로 옮겼다. 사이드바는 메뉴 옆 ★ 토글만 담당한다.
  const { isFavorite, toggleFavorite } = useFavorites();
  const [expandedMenus, setExpandedMenus] = useState<string[]>(() => [...defaultExpandedCodes]);

  const toggleMenu = (menuCode: string) => {
    if (collapsed) return;
    setExpandedMenus((prev) =>
      prev.includes(menuCode) ? prev.filter((c) => c !== menuCode) : [...prev, menuCode]
    );
  };

  const isMenuActive = (item: MenuConfigItem) => {
    if (item.path) return pathname === item.path;
    return item.children?.some((child) => pathname === child.path);
  };

  const sidebarWidth = collapsed ? "var(--sidebar-collapsed-width)" : "var(--sidebar-width)";
  const pinnedCodes = sidebarSections.pinned.codes;
  const adminCodes = sidebarSections.admin.codes;
  const workflowItems = items.filter(item => pinnedCodes.includes(item.code));
  /** 관리자 성격 그룹(인터페이스·시스템관리)은 업무 메뉴와 분리해 하단 고정 영역(전체 도움말 위)에 둔다 */
  const adminItems = items.filter(item => adminCodes.includes(item.code));
  const regularItems = items.filter(
    item => !pinnedCodes.includes(item.code) && !adminCodes.includes(item.code),
  );

  return (
    <>
      {isOpen && <div className="fixed inset-0 z-30 bg-black/50 lg:hidden print:hidden" onClick={onClose} />}
      <aside
        className={`fixed top-[var(--header-height)] left-0 z-30 flex h-[calc(100vh-var(--header-height))] flex-col overflow-hidden bg-surface border-r border-border transition-all duration-300 ease-in-out lg:translate-x-0 print:hidden ${isOpen ? "translate-x-0" : "-translate-x-full"}`}
        style={{ width: sidebarWidth }}
      >
        {/* 작은 화면 전용 칸(예: 고객사 선택). 큰 화면에서는 상단바에 있다. */}
        {sidebarTop && <div className="flex-shrink-0 border-b border-border p-3 sm:hidden">{sidebarTop}</div>}
        <nav className="min-h-0 flex-1 overflow-y-auto p-3" aria-label={t("menu.mainNav")}>
          <SidebarMenu
            items={regularItems}
            collapsed={collapsed}
            pathname={pathname}
            expandedMenus={expandedMenus}
            onToggleMenu={toggleMenu}
            isMenuActive={isMenuActive}
            isMenuDisabled={isMenuDisabled}
            onClose={onClose}
            t={t}
            isFavorite={isFavorite}
            onToggleFavorite={toggleFavorite}
            onMenuDragStart={(code) => { if (!isFavorite(code)) toggleFavorite(code); }}
          />
        </nav>
        <nav className="flex-shrink-0 border-t border-border bg-surface px-3 py-2" aria-label={sidebarSections.pinned.labelKeys.map((key) => t(key)).join(" · ")}>
          <SidebarMenu
            items={workflowItems}
            collapsed={collapsed}
            pathname={pathname}
            expandedMenus={expandedMenus}
            onToggleMenu={toggleMenu}
            isMenuActive={isMenuActive}
            isMenuDisabled={isMenuDisabled}
            onClose={onClose}
            t={t}
            isFavorite={isFavorite}
            onToggleFavorite={toggleFavorite}
            onMenuDragStart={(code) => { if (!isFavorite(code)) toggleFavorite(code); }}
          />
        </nav>
        {adminItems.length > 0 && (
          <nav className="flex-shrink-0 max-h-[45vh] overflow-y-auto border-t border-border bg-surface px-3 py-2" aria-label={sidebarSections.admin.labelKeys.map((key) => t(key)).join(" · ")}>
            <SidebarMenu
              items={adminItems}
              collapsed={collapsed}
              pathname={pathname}
              expandedMenus={expandedMenus}
              onToggleMenu={toggleMenu}
              isMenuActive={isMenuActive}
              isMenuDisabled={isMenuDisabled}
              onClose={onClose}
              t={t}
              isFavorite={isFavorite}
              onToggleFavorite={toggleFavorite}
              onMenuDragStart={(code) => { if (!isFavorite(code)) toggleFavorite(code); }}
            />
          </nav>
        )}
        {helpMenu && (
        <nav className="flex-shrink-0 border-t border-border bg-surface p-3">
          <SidebarMenu
            items={[helpMenu]}
            collapsed={collapsed}
            pathname={pathname}
            expandedMenus={expandedMenus}
            onToggleMenu={toggleMenu}
            isMenuActive={isMenuActive}
            isMenuDisabled={() => false}
            onClose={onClose}
            t={t}
          />
        </nav>
        )}
      </aside>
    </>
  );
}

export default Sidebar;
