"use client";

/**
 * @file shell/AppShell.tsx
 * @description 지성 웹 제품 공통 앱 틀. 헤더 + 사이드바 + 탭바 + keep-alive 본문.
 * 원본은 HANES MainLayout 이다. 틀의 모양과 동작(메뉴 흐림, 그룹 접힘, 즐겨찾기, 탭 유지)은 여기서 고정하고
 * 메뉴 데이터·즐겨찾기 저장·제품 전용 표시는 config 로 받는다.
 */
import { useState, type ReactNode } from "react";
import { usePathname } from "next/navigation";
import Header from "./Header";
import Sidebar from "./Sidebar";
import TabBar from "./TabBar";
import TabKeepAlive from "./TabKeepAlive";
import { ShellConfigContext } from "./ShellContext";
import { configureThemeStore, DEFAULT_THEME_STORAGE_KEY, isThemeStoreConfigured } from "./themeStore";
import type { AppShellConfig } from "./types";

export interface AppShellProps {
  config: AppShellConfig;
  children: ReactNode;
}

/**
 * 제품이 configureThemeStore 를 부르지 않았으면 테마가 복원되지 않는다. 기본 키로라도 복원하고 개발 중 알린다.
 * 첫 렌더 전에 끝나야 깜빡임이 없으므로 렌더 중 한 번만 실행한다(브라우저에서만).
 */
function ensureThemeStoreConfigured() {
  if (typeof window === "undefined" || isThemeStoreConfigured()) return;
  if (process.env.NODE_ENV !== "production") {
    console.warn(
      `@jisung/ui: configureThemeStore({ storageKey }) 가 호출되지 않아 기본 키 "${DEFAULT_THEME_STORAGE_KEY}" 로 테마를 저장합니다. 앱 시작 시 제품의 테마 저장 키로 호출하세요.`,
    );
  }
  void configureThemeStore({ storageKey: DEFAULT_THEME_STORAGE_KEY });
}

export function AppShell({ config, children }: AppShellProps) {
  ensureThemeStoreConfigured();
  const pathname = usePathname();
  const denied = config.canAccessPath ? !config.canAccessPath(pathname) : false;
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  return (
    <ShellConfigContext.Provider value={config}>
      <div className="h-screen overflow-hidden bg-background print:h-auto print:overflow-visible">
        {config.chromeless ? (
          <main className="h-screen overflow-hidden bg-background">
            {children}
          </main>
        ) : (
          <>
            <Header
              onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
              collapsed={collapsed}
              onToggleCollapse={() => setCollapsed(!collapsed)}
            />
            <Sidebar
              isOpen={sidebarOpen}
              onClose={() => setSidebarOpen(false)}
              collapsed={collapsed}
              onToggleCollapse={() => setCollapsed(!collapsed)}
            />
            <main
              className={`
              pt-[var(--header-height)] h-screen flex flex-col overflow-hidden transition-all duration-300
              print:block print:h-auto print:overflow-visible print:p-0
              ${collapsed ? "lg:pl-[var(--sidebar-collapsed-width)]" : "lg:pl-[var(--sidebar-width)]"}
            `}
            >
              <TabBar />
              <div className="flex-1 min-h-0 overflow-hidden print:overflow-visible">
                {denied ? config.accessDenied : <TabKeepAlive>{children}</TabKeepAlive>}
              </div>
            </main>
          </>
        )}
        {config.overlays}
      </div>
    </ShellConfigContext.Provider>
  );
}

export default AppShell;
