/**
 * @file src/stores/themeStore.ts
 * @description Zustand 기반 테마 상태 관리 스토어
 *
 * 개선사항:
 * 1. system 모드 지원 (OS 설정 따라가기)
 * 2. localStorage 동기화 (persist 미들웨어)
 * 3. HTML 클래스 자동 적용 (useThemeEffect 훅 제공)
 */
import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Theme = "light" | "dark" | "system";
export type ResolvedTheme = "light" | "dark";
export type ColorTheme = "default" | "custom" | "orchid";

interface ThemeState {
  theme: Theme;
  resolvedTheme: ResolvedTheme;
  colorTheme: ColorTheme;
  setTheme: (theme: Theme) => void;
  setColorTheme: (colorTheme: ColorTheme) => void;
  toggleTheme: () => void;
  _resolveTheme: (theme: Theme) => ResolvedTheme;
}

function getSystemTheme(): ResolvedTheme {
  if (typeof window === "undefined") return "light";
  return window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      theme: "system",
      resolvedTheme: "light",
      colorTheme: "default" as ColorTheme,

      setTheme: (theme: Theme) => {
        const resolved = theme === "system" ? getSystemTheme() : theme;
        set({ theme, resolvedTheme: resolved });
      },

      setColorTheme: (colorTheme: ColorTheme) => {
        set({ colorTheme });
      },

      toggleTheme: () => {
        const current = get().resolvedTheme;
        const next = current === "light" ? "dark" : "light";
        set({ theme: next, resolvedTheme: next });
      },

      _resolveTheme: (theme: Theme) => {
        return theme === "system" ? getSystemTheme() : theme;
      },
    }),
    {
      name: "jisung-theme",
      // 제품마다 저장 키가 달라 configureThemeStore 에서 키를 정한 뒤 읽는다.
      skipHydration: true,
      partialize: (state) => ({ theme: state.theme, colorTheme: state.colorTheme }),
      onRehydrateStorage: () => (state) => {
        // hydration 후 resolvedTheme 재계산
        if (state) {
          const resolved =
            state.theme === "system" ? getSystemTheme() : state.theme;
          state.resolvedTheme = resolved;
        }
      },
    }
  )
);

/**
 * 시스템 테마 변경 감지용 미디어쿼리 리스너
 * providers.tsx 또는 컴포넌트에서 사용
 */
export function listenSystemThemeChange(callback: (theme: ResolvedTheme) => void) {
  if (typeof window === "undefined") return () => {};
  
  const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
  const handler = (e: MediaQueryListEvent) => {
    callback(e.matches ? "dark" : "light");
  };
  
  mediaQuery.addEventListener("change", handler);
  return () => mediaQuery.removeEventListener("change", handler);
}

/** 제품이 저장 키를 정하지 않았을 때 AppShell 이 쓰는 기본 키 */
export const DEFAULT_THEME_STORAGE_KEY = "jisung-theme";

let themeConfigured = false;

/** configureThemeStore 가 불렸는지 */
export function isThemeStoreConfigured(): boolean {
  return themeConfigured;
}

/**
 * 제품이 앱 시작 시 한 번 호출한다. 테마 저장 키를 정하고 저장된 값을 읽는다.
 * HANES: "harness-theme", JSOverLoad: "jisung-theme". 키를 바꾸면 사용자의 테마 설정이 초기화된다.
 */
export function configureThemeStore({ storageKey }: { storageKey: string }): Promise<void> | void {
  themeConfigured = true;
  // 서버 렌더에는 localStorage 가 없어 persist 미들웨어가 persist API 를 붙이지 않는다. 읽을 저장값도 없다.
  if (!useThemeStore.persist) return;
  useThemeStore.persist.setOptions({ name: storageKey });
  return useThemeStore.persist.rehydrate();
}
