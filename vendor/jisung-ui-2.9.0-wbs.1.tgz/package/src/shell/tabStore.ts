/**
 * @file src/stores/tabStore.ts
 * @description Zustand 기반 탭 상태 관리 스토어
 *
 * 초보자 가이드:
 * 1. **Tab**: 열린 페이지를 나타내는 탭 객체 (id, path, labelKey, parentId)
 * 2. **pinned**: 고정 탭 (닫기 불가, 대시보드가 기본 고정)
 * 3. **비영속**: 탭 목록은 메모리에만 유지 — 새로고침/재진입 시 항상 초기 상태로 시작
 * 4. **최대 개수 제약**: 제품이 configureTabStore({ getMaxTabs }) 로 정하며, 미설정 시 기본 10개.
 *    한도에 도달한 상태에서 새 탭을 열면 추가를 차단하고 안내 모달을 띄운다
 */
import { create } from "zustand";

/** 탭 인터페이스 */
export interface Tab {
  /** 고유 ID (메뉴 아이템 id와 동일) */
  id: string;
  /** 라우트 경로 */
  path: string;
  /** i18n 번역 키 */
  labelKey: string;
  /** 부모 메뉴 ID (아이콘 조회용) */
  parentId: string;
  /** 고정 탭 여부 */
  pinned?: boolean;
  /** 메뉴에 없는 상세 경로 탭의 구분 표시(예: /csr/1024 → "1024"). 탭 이름 뒤에 붙는다. */
  suffix?: string;
  /** 탭의 메뉴 경로. 상세를 같은 탭에서 열 때(detailInParentTab) path 가 상세로 바뀌어도 목록 화면을 살려 두는 데 쓴다. */
  basePath?: string;
}

/** 제품이 최대 탭 수를 정하지 않았을 때의 기본값 (고정 탭 포함) */
export const DEFAULT_MAX_TABS = 10;

/** 설정값을 양의 정수로 정규화 — 비정상값이면 기본값으로 대체 */
export function normalizeMaxTabs(value: number): number {
  return Number.isFinite(value) && value > 0 ? Math.floor(value) : DEFAULT_MAX_TABS;
}

export interface TabStoreConfig {
  /** 항상 열려 있는 고정 탭(예: 대시보드). 없으면 null */
  homeTab: Omit<Tab, "pinned"> | null;
  /** 현재 최대 탭 수. 스토어 밖(React 외부)에서도 호출된다 */
  getMaxTabs: () => number;
}

let tabConfig: TabStoreConfig = { homeTab: null, getMaxTabs: () => DEFAULT_MAX_TABS };

/**
 * 제품이 앱 시작 시 한 번 호출한다. homeTab 을 고정 탭으로 넣고, 열린 탭이 없으면 활성화한다.
 */
export function configureTabStore(next: Partial<TabStoreConfig>): void {
  tabConfig = { ...tabConfig, ...next };
  const home = next.homeTab;
  if (!home) return;
  const { tabs, activeTabId } = useTabStore.getState();
  if (tabs.some((t) => t.id === home.id)) return;
  useTabStore.setState({ tabs: [{ ...home, pinned: true }, ...tabs], activeTabId: activeTabId ?? home.id });
}

interface TabState {
  tabs: Tab[];
  activeTabId: string | null;
  /** 탭 최대 개수 초과 안내 모달 표시 여부 */
  limitNoticeOpen: boolean;
  /** 탭 추가. 최대 개수 초과로 차단되면 false를 반환한다 */
  addTab: (tab: Omit<Tab, "pinned">) => boolean;
  removeTab: (tabId: string) => void;
  setActiveTab: (tabId: string) => void;
  closeOtherTabs: (tabId: string) => void;
  closeAllTabs: () => void;
  syncActiveTabByPath: (pathname: string) => void;
  /** 탭이 보여 줄 경로를 바꾼다(같은 탭에서 상세 ↔ 목록). 처음 경로는 basePath 로 남긴다. */
  setTabPath: (tabId: string, path: string) => void;
  closeLimitNotice: () => void;
}

export const useTabStore = create<TabState>()((set, get) => ({
  tabs: [],
  activeTabId: null,
  limitNoticeOpen: false,

  addTab: (tab) => {
    const { tabs } = get();
    const existing = tabs.find((t) => t.id === tab.id);

    if (existing) {
      set({ activeTabId: existing.id });
      return true;
    }

    // 최대 탭 수 도달 시 추가 차단 + 안내 모달
    if (tabs.length >= normalizeMaxTabs(tabConfig.getMaxTabs())) {
      set({ limitNoticeOpen: true });
      return false;
    }

    set({ tabs: [...tabs, { ...tab, pinned: false }], activeTabId: tab.id });
    return true;
  },

  removeTab: (tabId) => {
    const { tabs, activeTabId } = get();
    const tab = tabs.find((t) => t.id === tabId);
    if (!tab || tab.pinned) return;

    const tabIndex = tabs.findIndex((t) => t.id === tabId);
    const newTabs = tabs.filter((t) => t.id !== tabId);

    // 활성 탭을 닫은 경우 인접 탭 활성화
    if (activeTabId === tabId && newTabs.length > 0) {
      const nextTab =
        newTabs[tabIndex] || newTabs[tabIndex - 1] || newTabs[0];
      set({ tabs: newTabs, activeTabId: nextTab.id });
    } else {
      set({ tabs: newTabs });
    }
  },

  setActiveTab: (tabId) => {
    set({ activeTabId: tabId });
  },

  closeOtherTabs: (tabId) => {
    const { tabs } = get();
    const newTabs = tabs.filter((t) => t.id === tabId || t.pinned);
    set({ tabs: newTabs, activeTabId: tabId });
  },

  closeAllTabs: () => {
    const { tabs } = get();
    const pinnedTabs = tabs.filter((t) => t.pinned);
    const activeId = pinnedTabs.length > 0 ? pinnedTabs[0].id : null;
    set({ tabs: pinnedTabs, activeTabId: activeId });
  },

  syncActiveTabByPath: (pathname) => {
    const { tabs } = get();
    const matched = tabs.find((t) => t.path === pathname);
    if (matched) {
      set({ activeTabId: matched.id });
    }
  },

  setTabPath: (tabId, path) => {
    set({
      tabs: get().tabs.map((t) => (t.id === tabId ? { ...t, basePath: t.basePath ?? t.path, path } : t)),
      activeTabId: tabId,
    });
  },

  closeLimitNotice: () => {
    set({ limitNoticeOpen: false });
  },
}));
