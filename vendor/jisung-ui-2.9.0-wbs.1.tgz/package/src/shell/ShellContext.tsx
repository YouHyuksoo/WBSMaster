"use client";

/**
 * @file shell/ShellContext.tsx
 * @description AppShell 설정을 틀 안의 컴포넌트(헤더·사이드바·탭)에 전달한다.
 */
import { createContext, useContext } from "react";
import type { AppShellConfig, MenuNode } from "./types";

export const ShellConfigContext = createContext<AppShellConfig | null>(null);

export function useShellConfig(): AppShellConfig {
  const config = useContext(ShellConfigContext);
  if (!config) throw new Error("@jisung/ui: AppShell 밖에서 앱 틀 컴포넌트를 쓸 수 없습니다.");
  return config;
}

/** 경로로 메뉴 항목과 최상위 부모 코드를 찾는다 (2단계 메뉴) */
export function findMenuItemByPath(menu: MenuNode[], path: string): { item: MenuNode; parentCode: string } | undefined {
  for (const item of menu) {
    if (item.path === path) return { item, parentCode: item.code };
    for (const child of item.children ?? []) {
      if (child.path === path) return { item: child, parentCode: item.code };
    }
  }
  return undefined;
}
