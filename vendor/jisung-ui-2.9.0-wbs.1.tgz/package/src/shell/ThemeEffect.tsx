"use client";

/**
 * @file shell/ThemeEffect.tsx
 * @description 테마 스토어 값을 <html> 에 반영한다 (원본: HANES providers.tsx ThemeEffect).
 * - light/dark 클래스 (Tailwind dark 변형과 tokens.css 의 .dark 토큰)
 * - data-color-theme 속성 (custom/orchid 팔레트, default 는 속성 없음)
 * - system 모드면 OS 테마 변경을 따라간다
 * 제품은 루트 provider 안에 한 번 렌더한다.
 */
import { useEffect } from "react";
import { listenSystemThemeChange, useThemeStore } from "./themeStore";

export function ThemeEffect() {
  const { theme, colorTheme, _resolveTheme } = useThemeStore();

  // 초기 테마 설정 및 HTML 클래스 적용
  useEffect(() => {
    const resolved = _resolveTheme(theme);
    const root = document.documentElement;

    root.classList.remove("light", "dark");
    root.classList.add(resolved);

    // store의 resolvedTheme 동기화
    if (useThemeStore.getState().resolvedTheme !== resolved) {
      useThemeStore.setState({ resolvedTheme: resolved });
    }
  }, [theme, _resolveTheme]);

  // 컬러 테마 적용
  useEffect(() => {
    const root = document.documentElement;
    if (colorTheme === "default") {
      root.removeAttribute("data-color-theme");
    } else {
      root.setAttribute("data-color-theme", colorTheme);
    }
  }, [colorTheme]);

  // system 모드일 때 OS 테마 변경 감지
  useEffect(() => {
    if (theme !== "system") return;

    return listenSystemThemeChange((resolved) => {
      const root = document.documentElement;
      root.classList.remove("light", "dark");
      root.classList.add(resolved);
      useThemeStore.setState({ resolvedTheme: resolved });
    });
  }, [theme]);

  return null;
}

export default ThemeEffect;
