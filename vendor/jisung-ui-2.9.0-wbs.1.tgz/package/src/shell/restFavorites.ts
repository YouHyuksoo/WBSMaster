"use client";

/**
 * @file shell/restFavorites.ts
 * @description 표준 즐겨찾기 API 를 쓰는 즐겨찾기·폴더 훅을 만든다. 제품 백엔드가 아래 규격만 지키면
 * AppShellConfig.useFavorites / useFavoriteFolders 에 그대로 넘길 수 있다. (규격 원본: HANES menu-favorites)
 *
 *   GET    {base}/me                     → string[]                  내 즐겨찾기 메뉴 코드(표시 순서)
 *   PUT    {base}/me        { menuCodes } → string[]                  전체 교체
 *   GET    {base}/folders                 → { folders, assignments }
 *   POST   {base}/folders   { name }                                  폴더 추가
 *   PATCH  {base}/folders/:id { name }                                폴더 이름 변경
 *   DELETE {base}/folders/:id                                         폴더 삭제
 *   PUT    {base}/me/:menuCode/folder { folderId }                    메뉴를 폴더로 이동(null = 폴더 없음)
 *
 * 응답은 값 그대로 또는 { data: 값 } 둘 다 받는다. 사용자·회사가 바뀌면 useScopeKey 값을 바꿔 다시 읽는다.
 */
import { useCallback, useEffect, useSyncExternalStore } from "react";
import type { FavoriteFolder, FavoriteFolderAction, FavoriteFoldersApi, FavoritesApi } from "./types";

export type FavoritesRequest = (method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE", url: string, body?: unknown) => Promise<unknown>;

export interface RestFavoritesOptions {
  /** HTTP 호출. 제품의 API 클라이언트(인증 헤더 포함)로 구현하고 응답 본문을 돌려준다. */
  request: FavoritesRequest;
  /** 기본 "/menu-favorites" */
  baseUrl?: string;
  /** false 면 요청하지 않는다(로그인 전 등) — React 훅 */
  useEnabled?: () => boolean;
  /** 사용자·회사 같은 범위 값. 바뀌면 다시 읽는다 — React 훅 */
  useScopeKey?: () => string;
  /** 사용자에게 보여줄 오류 안내(토스트 등) */
  onError?: (message: string) => void;
}

type FolderData = { folders: FavoriteFolder[]; assignments: { menuCode: string; folderId: number | null }[] };

const unwrap = <T,>(res: unknown): T =>
  (res && typeof res === "object" && "data" in (res as Record<string, unknown>) ? (res as { data: T }).data : res) as T;

function serverMessage(error: unknown): string | undefined {
  const message = (error as { response?: { data?: { message?: unknown } } })?.response?.data?.message;
  return typeof message === "string" ? message : undefined;
}

function createStore<S>(initial: S) {
  let state = initial;
  const listeners = new Set<() => void>();
  return {
    get: () => state,
    set: (patch: Partial<S>) => {
      state = { ...state, ...patch };
      listeners.forEach((l) => l());
    },
    subscribe: (l: () => void) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
  };
}

export function createRestFavorites(options: RestFavoritesOptions): {
  useFavorites: () => FavoritesApi;
  useFavoriteFolders: () => FavoriteFoldersApi;
} {
  const base = options.baseUrl ?? "/menu-favorites";
  const useEnabled = options.useEnabled ?? (() => true);
  const useScopeKey = options.useScopeKey ?? (() => "");
  const notify = (message: string) => options.onError?.(message);

  const favStore = createStore({
    list: null as string[] | null,
    loading: false,
    error: false,
    saving: false,
    scope: null as string | null,
  });

  async function loadFavorites(scope: string) {
    favStore.set({ loading: true, error: false, scope });
    try {
      const list = unwrap<string[]>(await options.request("GET", `${base}/me`));
      if (favStore.get().scope === scope) favStore.set({ list: list ?? [], loading: false });
    } catch {
      if (favStore.get().scope === scope) favStore.set({ loading: false, error: true });
    }
  }

  function useFavorites(): FavoritesApi {
    const enabled = useEnabled();
    const scope = useScopeKey();
    const state = useSyncExternalStore(favStore.subscribe, favStore.get, favStore.get);

    useEffect(() => {
      if (!enabled) return;
      const current = favStore.get();
      if (current.scope !== scope || (current.list === null && !current.loading)) void loadFavorites(scope);
    }, [enabled, scope]);

    const favorites = state.scope === scope && state.list ? state.list : [];
    const isFavorite = useCallback((code: string) => favorites.includes(code), [favorites]);

    const toggleFavorite = useCallback(
      (code: string) => {
        const current = favStore.get();
        // 전체 교체 API 이므로 원래 목록을 읽기 전에 빈 배열로 덮어쓰지 않는다.
        if (!enabled || current.scope !== scope || current.list === null || current.loading || current.error || current.saving) {
          notify("즐겨찾기를 불러오거나 저장하는 중입니다. 잠시 후 다시 시도해 주세요.");
          return;
        }
        const next = current.list.includes(code) ? current.list.filter((c) => c !== code) : [...current.list, code];
        favStore.set({ list: next, saving: true });
        options
          .request("PUT", `${base}/me`, { menuCodes: next })
          .then((res) => {
            if (favStore.get().scope === scope) favStore.set({ list: unwrap<string[]>(res) ?? next, saving: false });
          })
          .catch(() => {
            favStore.set({ saving: false });
            notify("즐겨찾기를 저장하지 못했습니다. 다시 시도해 주세요.");
            void loadFavorites(scope);
          });
      },
      [enabled, scope],
    );

    return { favorites, isFavorite, toggleFavorite };
  }

  const folderStore = createStore({
    data: null as FolderData | null,
    loading: false,
    error: false,
    saving: false,
    scope: null as string | null,
  });

  async function loadFolders(scope: string) {
    folderStore.set({ loading: true, error: false, scope });
    try {
      const data = unwrap<FolderData>(await options.request("GET", `${base}/folders`));
      if (folderStore.get().scope === scope) folderStore.set({ data, loading: false });
    } catch {
      if (folderStore.get().scope === scope) folderStore.set({ loading: false, error: true });
    }
  }

  function requestFor(action: FavoriteFolderAction): Promise<unknown> {
    switch (action.type) {
      case "create":
        return options.request("POST", `${base}/folders`, { name: action.name });
      case "rename":
        return options.request("PATCH", `${base}/folders/${action.id}`, { name: action.name });
      case "delete":
        return options.request("DELETE", `${base}/folders/${action.id}`);
      case "move":
        return options.request("PUT", `${base}/me/${encodeURIComponent(action.menuCode)}/folder`, { folderId: action.folderId });
    }
  }

  function useFavoriteFolders(): FavoriteFoldersApi {
    const enabled = useEnabled();
    const scope = useScopeKey();
    const state = useSyncExternalStore(folderStore.subscribe, folderStore.get, folderStore.get);

    useEffect(() => {
      if (!enabled) return;
      const current = folderStore.get();
      if (current.scope !== scope || (current.data === null && !current.loading)) void loadFolders(scope);
    }, [enabled, scope]);

    const reload = useCallback(() => loadFolders(scope), [scope]);
    const save = useCallback(
      async (action: FavoriteFolderAction) => {
        folderStore.set({ saving: true });
        try {
          const res = await requestFor(action);
          await loadFolders(scope);
          return res;
        } catch (error: unknown) {
          notify(serverMessage(error) ?? "즐겨찾기 폴더를 저장하지 못했습니다.");
          throw error;
        } finally {
          folderStore.set({ saving: false });
        }
      },
      [scope],
    );

    const data = state.scope === scope ? state.data : null;
    return {
      folders: data?.folders ?? [],
      assignments: data?.assignments ?? [],
      loading: state.loading,
      error: state.error,
      reload,
      save,
      saving: state.saving,
    };
  }

  return { useFavorites, useFavoriteFolders };
}
