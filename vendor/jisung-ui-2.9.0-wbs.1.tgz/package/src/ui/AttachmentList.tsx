"use client";

/**
 * @file ui/AttachmentList.tsx
 * @description 올리기 전 첨부 파일 목록. 이미지는 썸네일, 그 밖의 파일은 이름·크기 줄로 보이고, 하나씩 뺄 수 있다.
 * 클립보드 이미지 붙여넣기는 pastedImageFiles 로 받는다 — 입력칸·폼의 onPaste 에서 꺼낸 파일을 목록에 더한다.
 *
 * 쓰는 법:
 *   <form onPaste={(e) => { const add = pastedImageFiles(e); if (add.length) { e.preventDefault(); setFiles((f) => [...f, ...add]); } }}>
 *   <AttachmentList files={files} onRemove={(i) => setFiles((f) => f.filter((_, n) => n !== i))} />
 */
import { useEffect, useState } from "react";
import { Paperclip, X } from "lucide-react";
import { useTranslation } from "react-i18next";

const PASTE_EXTENSIONS: Record<string, string> = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" };

const pad = (n: number) => String(n).padStart(2, "0");

/**
 * 붙여넣기 이벤트의 이미지 파일(png·jpg·webp). 화면 캡처처럼 이미지만 있을 때만 꺼낸다 —
 * 엑셀 셀 복사처럼 글자와 그림이 함께 오면 글자 붙여넣기가 맞으므로 빈 배열을 돌려준다.
 * 클립보드 이미지는 이름이 모두 image.png 라서 paste-연월일-시분초-순번.확장자 로 바꾼다.
 */
export function pastedImageFiles(event: { clipboardData: DataTransfer | null }, now = new Date()): File[] {
  const data = event.clipboardData;
  if (!data || data.types.includes("text/plain")) return [];
  const stamp =
    `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-` +
    `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
  return Array.from(data.files)
    .filter((file) => file.type in PASTE_EXTENSIONS)
    .map(
      (file, index) =>
        new File([file], `paste-${stamp}-${index + 1}.${PASTE_EXTENSIONS[file.type]}`, {
          type: file.type,
          lastModified: now.getTime(),
        }),
    );
}

function fileSize(bytes: number) {
  return bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(1)}KB` : `${(bytes / 1024 / 1024).toFixed(1)}MB`;
}

function useObjectUrls(files: File[]) {
  const [urls, setUrls] = useState<(string | null)[]>([]);
  useEffect(() => {
    const next = files.map((file) => (file.type.startsWith("image/") ? URL.createObjectURL(file) : null));
    setUrls(next);
    return () => next.forEach((url) => url && URL.revokeObjectURL(url));
  }, [files]);
  return urls;
}

export interface AttachmentListProps {
  files: File[];
  /** 주면 파일마다 빼기 버튼이 생긴다 */
  onRemove?: (index: number) => void;
  disabled?: boolean;
  className?: string;
}

export function AttachmentList({ files, onRemove, disabled, className = "" }: AttachmentListProps) {
  const { t } = useTranslation();
  const urls = useObjectUrls(files);
  if (!files.length) return null;
  const remove = (index: number, name: string) =>
    onRemove ? (
      <button
        type="button"
        disabled={disabled}
        onClick={() => onRemove(index)}
        aria-label={t("attachments.remove", { name })}
        className="flex-shrink-0 rounded p-0.5 text-text-muted hover:bg-primary/10 hover:text-primary focus:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:opacity-50"
      >
        <X className="w-3.5 h-3.5" aria-hidden="true" />
      </button>
    ) : null;
  return (
    <ul aria-label={t("attachments.list")} className={`flex flex-wrap gap-2 ${className}`}>
      {files.map((file, index) => {
        const url = urls[index];
        const key = `${index}-${file.name}-${file.size}`;
        return url ? (
          <li key={key} className="w-32 overflow-hidden rounded-[var(--radius)] border border-border bg-surface">
            <img src={url} alt={file.name} className="block h-24 w-full object-cover bg-background" />
            <div className="flex items-center gap-1 px-2 py-1 text-xs text-text-muted">
              <span className="min-w-0 flex-1 truncate" title={file.name}>
                {file.name}
              </span>
              {remove(index, file.name)}
            </div>
          </li>
        ) : (
          <li
            key={key}
            className="flex max-w-full items-center gap-1.5 self-start rounded-[var(--radius)] border border-border bg-surface px-2 py-1 text-sm text-text-muted"
          >
            <Paperclip className="w-3.5 h-3.5 flex-shrink-0" aria-hidden="true" />
            <span className="min-w-0 truncate" title={file.name}>
              {file.name}
            </span>
            <span className="flex-shrink-0">({fileSize(file.size)})</span>
            {remove(index, file.name)}
          </li>
        );
      })}
    </ul>
  );
}

export default AttachmentList;
