"use client";

/**
 * @file ui/BodyPortal.tsx
 * @description document.body 로 띄우는 오버레이(모달·팝업·툴팁·전체화면 그리드)의 공통 포털.
 * 탭 keep-alive 에서 화면이 숨어도 body 포털은 따라 숨지 않아 다른 탭을 덮는다.
 * 그래서 자기 탭이 숨으면 함께 숨기고(display:none, 상태 유지), 보이면 레이아웃에 영향 없이(display:contents) 그린다.
 */
import type { ReactNode } from "react";
import { createPortal } from "react-dom";
import { useIsTabActive } from "../shell/TabActivity";

export function BodyPortal({ children }: { children: ReactNode }) {
  const active = useIsTabActive();
  if (typeof document === "undefined") return null;
  return createPortal(<div style={{ display: active ? "contents" : "none" }}>{children}</div>, document.body);
}

export default BodyPortal;
