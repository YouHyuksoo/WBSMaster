"use client";

/**
 * @file ui/Tabs.tsx
 * @description 화면 안 보기 전환 탭(관제 자산 / 경보 이력 등). HANES 화면들이 직접 쓰던 밑줄 탭(limit-sample 등)을 컴포넌트로 뽑았다.
 * role=tablist/tab, 고른 탭만 aria-selected·Tab 키 대상(roving tabindex), 좌우 화살표·Home/End 로 옮긴다.
 * 앱 틀의 상단 탭(TabBar, 화면 탭)과는 다르다.
 */
import { useRef, type ReactNode } from "react";

export interface TabItem {
  value: string;
  label: ReactNode;
  icon?: ReactNode;
}

export interface TabsProps {
  items: TabItem[];
  value: string;
  onChange: (value: string) => void;
  /** tablist 이름(스크린리더) */
  label?: string;
  className?: string;
}

export function Tabs({ items, value, onChange, label, className = "" }: TabsProps) {
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  function move(index: number) {
    const next = (index + items.length) % items.length;
    onChange(items[next].value);
    refs.current[next]?.focus();
  }
  return (
    <div role="tablist" aria-label={label} className={`flex gap-1 border-b border-border flex-shrink-0 overflow-x-auto ${className}`}>
      {items.map((item, index) => {
        const selected = item.value === value;
        return (
          <button
            key={item.value}
            ref={(el) => {
              refs.current[index] = el;
            }}
            type="button"
            role="tab"
            aria-selected={selected}
            tabIndex={selected ? 0 : -1}
            onClick={() => onChange(item.value)}
            onKeyDown={(e) => {
              if (e.key === "ArrowRight") move(index + 1);
              else if (e.key === "ArrowLeft") move(index - 1);
              else if (e.key === "Home") move(0);
              else if (e.key === "End") move(items.length - 1);
              else return;
              e.preventDefault();
            }}
            className={`inline-flex items-center gap-1.5 whitespace-nowrap px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${
              selected ? "border-primary text-primary" : "border-transparent text-text-muted hover:text-text"
            }`}
          >
            {item.icon}
            {item.label}
          </button>
        );
      })}
    </div>
  );
}

export default Tabs;
