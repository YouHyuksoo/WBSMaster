"use client";

/**
 * @file ui/Field.tsx
 * @description 라벨 + 아무 입력 요소(여러 개 선택 select, textarea, 파일 등) + 도움말·오류.
 * Input/Select 처럼 전용 컴포넌트가 없는 입력에 쓴다. 라벨·도움말·오류를 id 로 이어 주고(useId — keep-alive 로
 * 같은 화면이 두 번 떠도 겹치지 않는다), 직접 만든 입력에는 fieldControlClass 로 표준 모양을 입힌다.
 */
import { cloneElement, isValidElement, useId, type ReactElement, type ReactNode } from "react";

/** Field 안에 직접 넣는 select·textarea 에 붙이는 표준 입력 모양(Input 과 같은 테두리·포커스) */
export const fieldControlClass =
  "w-full px-3 py-2 bg-surface border border-gray-400 dark:border-gray-500 rounded-[var(--radius)] text-text text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed";

type ControlProps = { id?: string; "aria-describedby"?: string; "aria-invalid"?: boolean | "true" | "false" };

export interface FieldProps {
  label: ReactNode;
  required?: boolean;
  hint?: ReactNode;
  error?: string;
  className?: string;
  children: ReactElement<ControlProps>;
}

export function Field({ label, required, hint, error, className = "", children }: FieldProps) {
  const autoId = useId();
  const control = isValidElement<ControlProps>(children) ? children : null;
  const id = control?.props.id || autoId;
  const hintId = hint && !error ? id + "-hint" : undefined;
  const errorId = error ? id + "-error" : undefined;
  const describedBy = [control?.props["aria-describedby"], hintId, errorId].filter(Boolean).join(" ") || undefined;
  return (
    <div className={className}>
      <label htmlFor={id} className="block text-sm font-medium text-text mb-1.5">
        {label}
        {required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      {control
        ? cloneElement(control, { id, "aria-describedby": describedBy, ...(error ? { "aria-invalid": true } : {}) })
        : children}
      {hintId && <p id={hintId} className="mt-1.5 text-sm text-text-muted">{hint}</p>}
      {error && <p id={errorId} className="mt-1.5 text-sm text-error">{error}</p>}
    </div>
  );
}

export default Field;
