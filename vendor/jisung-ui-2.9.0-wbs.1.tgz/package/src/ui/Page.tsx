/**
 * @file ui/Page.tsx
 * @description 탭 안 화면의 표준 바깥 틀. 화면이 스스로 스크롤하고(앱 틀은 스크롤하지 않는다) 기본 여백 p-6 을 준다.
 * 인쇄할 때는 높이 제한을 풀어 전체 내용이 인쇄되게 한다.
 * panel(등록·수정 FormPanel 등)을 주면 본문 오른쪽에 여백 없이 붙인다(HANES 목록 + 오른쪽 패널 배치).
 */
import type { ReactNode } from "react";

export interface PageProps {
  className?: string;
  /** 본문 오른쪽에 붙는 패널. 보통 FormPanel. */
  panel?: ReactNode;
  children: ReactNode;
}

const BODY = "h-full overflow-y-auto p-6 max-sm:p-4 print:h-auto print:overflow-visible print:p-0";

export function Page({ className = "", panel, children }: PageProps) {
  if (!panel) return <div className={`${BODY} ${className}`}>{children}</div>;
  return (
    <div className="flex h-full print:block print:h-auto">
      <div className={`flex-1 min-w-0 ${BODY} ${className}`}>{children}</div>
      {panel}
    </div>
  );
}

export default Page;
