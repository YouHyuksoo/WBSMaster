"use client";

/**
 * @file ui/PageHeader.tsx
 * @description 화면 상단 제목 영역. HANES 목록 화면(거래처관리 등)이 직접 쓰던 마크업을 그대로 컴포넌트로 만들었다.
 * 왼쪽: 아이콘 + 제목, 부제(건수). 오른쪽: 새로고침·등록 같은 액션.
 */
import type { ComponentType, ReactNode } from "react";
import { useTranslation } from "react-i18next";

export interface PageHeaderProps {
  icon?: ComponentType<{ className?: string }>;
  title: ReactNode;
  subtitle?: ReactNode;
  count?: number;
  actions?: ReactNode;
}

export function PageHeader({ icon: Icon, title, subtitle, count, actions }: PageHeaderProps) {
  const { t } = useTranslation();
  return (
    <div className="flex flex-wrap justify-between items-center gap-x-4 gap-y-2 flex-shrink-0">
      <div className="min-w-0">
        <h1 className="text-xl font-bold text-text flex items-center gap-2">
          {Icon && <Icon className="w-7 h-7 text-primary" />}
          {title}
        </h1>
        {(subtitle !== undefined || count !== undefined) && (
          <p className="text-text-muted mt-1">
            {subtitle}
            {count !== undefined && ` (${t("common.countValue", { count, defaultValue: `${count}건` })})`}
          </p>
        )}
      </div>
      {actions && <div className="flex flex-shrink-0 flex-wrap items-center gap-2 whitespace-nowrap">{actions}</div>}
    </div>
  );
}

export default PageHeader;
