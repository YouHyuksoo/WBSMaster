"use client";

/**
 * @file ui/Loading.tsx
 * @description 표가 아닌 영역(대화상자·카드)에서 자료를 불러오는 동안 보이는 안내. 표는 DataGrid 의 isLoading 을 쓴다.
 */
import { Loader2 } from "lucide-react";
import { useTranslation } from "react-i18next";

export interface LoadingProps {
  message?: string;
  className?: string;
}

export function Loading({ message, className = "" }: LoadingProps) {
  const { t } = useTranslation();
  return (
    <div role="status" className={`flex items-center gap-2 py-6 text-sm text-text-muted ${className}`}>
      <Loader2 className="w-4 h-4 animate-spin text-primary" aria-hidden="true" />
      {message ?? t("common.loading")}
    </div>
  );
}

export default Loading;
