"use client";

/**
 * @file ui/SectionCard.tsx
 * @description 상세·현황 화면의 구획 카드. 제목(h2) + 오른쪽 칸(건수·버튼) + 본문.
 * 제목을 이름으로 가진 region 이라 스크린리더·시험에서 "백그라운드 처리" 구획처럼 찾을 수 있다. 인쇄 때 잘리지 않는다.
 */
import { useId, type ReactNode } from "react";
import { Card } from "./Card";

export interface SectionCardProps {
  title: ReactNode;
  /** 제목 오른쪽(건수, 버튼, 링크) */
  aside?: ReactNode;
  className?: string;
  children: ReactNode;
}

export function SectionCard({ title, aside, className = "", children }: SectionCardProps) {
  const titleId = useId();
  return (
    <section aria-labelledby={titleId} className={`print:break-inside-avoid ${className}`}>
      <Card padding="none" className="print:border-0 print:shadow-none">
        <div className="p-5 space-y-3 print:px-0">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 id={titleId} className="text-base font-semibold text-text">
              {title}
            </h2>
            {aside}
          </div>
          {children}
        </div>
      </Card>
    </section>
  );
}

export default SectionCard;
