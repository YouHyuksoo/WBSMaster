/**
 * @file ui/ErrorMessage.tsx
 * @description 화면·폼 위에 띄우는 오류 안내 상자. 메시지가 없으면 그리지 않는다. alert/confirm 대신 쓴다.
 */
export interface ErrorMessageProps {
  message?: string | null;
  className?: string;
}

export function ErrorMessage({ message, className = "" }: ErrorMessageProps) {
  if (!message) return null;
  return (
    <div role="alert" className={`rounded-[var(--radius)] border border-error/30 bg-error/10 px-3 py-2 text-sm text-error ${className}`}>
      {message}
    </div>
  );
}

export default ErrorMessage;
