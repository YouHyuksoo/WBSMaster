"use client";

/**
 * @file ui/FormPanel.tsx
 * @description 등록·수정용 오른쪽 패널. 그리드 옆에 붙는다(오버레이 아님).
 * HANES 의 *FormPanel 바깥 틀(폭 480px, border-l, 헤더에 제목과 취소·저장)을 표준으로 뽑았다.
 * 취소는 내장 버튼이며, dirty 면 저장하지 않은 변경 확인 후 닫는다.
 * 제목을 이름으로 가진 region 이다. 휴대폰 폭에서는 화면 전체를 덮는다. 인쇄에는 나오지 않는다.
 * 저장 버튼은 actions 에 `<Button type="submit" form={폼 id}>` 로 넘기면 본문 form 을 제출한다.
 */
import { useId, type ReactNode } from "react";
import { useTranslation } from "react-i18next";
import Button from "./Button";
import { ConfirmModal } from "./Modal";
import { useUnsavedGuard } from "../hooks/useUnsavedGuard";

export interface FormPanelProps {
  open: boolean;
  title: ReactNode;
  onClose: () => void;
  /** 작성 중인 변경이 있으면 true. 닫기 전에 확인한다. */
  dirty?: boolean;
  /** 헤더 오른쪽, 취소 버튼 뒤에 붙는 액션(저장 등) */
  actions?: ReactNode;
  /** 처음 열릴 때 오른쪽에서 밀려 들어오는 효과 */
  animate?: boolean;
  /** 패널 폭(px). 기본 480 */
  width?: number;
  /** 닫기 버튼 이름. 기본은 "취소", 보기용(상세) 패널은 "닫기" 등 */
  closeLabel?: ReactNode;
  children: ReactNode;
}

export function FormPanel({ open, title, onClose, dirty = false, actions, animate = false, width = 480, closeLabel, children }: FormPanelProps) {
  const { t } = useTranslation();
  const titleId = useId();
  const { markDirty, guard, guardModalProps } = useUnsavedGuard();
  markDirty(dirty);

  if (!open) return null;

  return (
    <section
      aria-labelledby={titleId}
      className={`border-l border-border bg-background flex flex-col h-full flex-shrink-0 overflow-hidden shadow-2xl text-xs max-sm:fixed max-sm:inset-0 max-sm:z-40 max-sm:!w-full max-sm:border-l-0 print:hidden ${animate ? "animate-slide-in-right" : ""}`}
      style={{ width }}
    >
      <div className="px-5 py-3 border-b border-border flex items-center justify-between flex-shrink-0">
        <h2 id={titleId} className="text-sm font-bold text-text">{title}</h2>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="secondary" onClick={() => guard(onClose)}>
            {closeLabel ?? t("common.cancel")}
          </Button>
          {actions}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-5 py-3 space-y-4">{children}</div>
      <ConfirmModal {...guardModalProps} />
    </section>
  );
}

export default FormPanel;
