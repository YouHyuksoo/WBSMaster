"use client";

/**
 * @file provider/UIProvider.tsx
 * @description 제품마다 다른 기능을 공용 컴포넌트에 넘기는 어댑터 컨텍스트.
 * 넘기지 않은 어댑터는 기본 동작(HelpTarget = children 그대로)을 쓰거나 기능을 숨긴다.
 */
import { createContext, useContext, useMemo, type ComponentType, type ReactNode } from "react";
import type { CommonCodeData } from "../common-codes/commonCodes";

/** SqlViewerModal 의 테이블 명세 컬럼 */
export interface ColumnInfo {
  columnId: number;
  columnName: string;
  dataType: string;
  dataLength: number | null;
  dataPrecision: number | null;
  dataScale: number | null;
  nullable: "Y" | "N";
  comments: string | null;
}

export interface TableSchema {
  tableName: string;
  tableComment: string | null;
  columns: ColumnInfo[];
}

export interface HelpTargetProps {
  helpKey: string;
  label: string;
  fallbackDescription?: string;
  children: ReactNode;
}

export interface UIAdapters {
  /** 투어/도움말 대상 표시. 기본값은 children 을 그대로 렌더한다. */
  HelpTarget?: ComponentType<HelpTargetProps>;
  /** DataGrid SQL 보기의 테이블 명세 조회. 없으면 명세 보기 기능을 숨긴다. */
  fetchTableColumns?: (tableName: string) => Promise<TableSchema>;
  /** 미리보기 SQL 에 해당하는 실제 실행 SQL(최근 API 응답에서 수집). 없으면 미리보기 SQL 을 그대로 보여준다. */
  getActualSql?: (previewSql: string) => string | null;
  /** 공통코드 전체(묶음·코드) 조회. 없으면 공통코드 부품은 빈 목록·코드 그대로 보인다. */
  fetchCommonCodes?: () => Promise<CommonCodeData>;
}

function PassthroughHelpTarget({ children }: HelpTargetProps) {
  return <>{children}</>;
}

type ResolvedAdapters = UIAdapters & { HelpTarget: ComponentType<HelpTargetProps> };

const DEFAULTS: ResolvedAdapters = { HelpTarget: PassthroughHelpTarget };

const UIAdaptersContext = createContext<ResolvedAdapters>(DEFAULTS);

export function JisungUIProvider({ adapters, children }: { adapters?: UIAdapters; children: ReactNode }) {
  const value = useMemo<ResolvedAdapters>(() => ({ ...DEFAULTS, ...adapters, HelpTarget: adapters?.HelpTarget ?? PassthroughHelpTarget }), [adapters]);
  return <UIAdaptersContext.Provider value={value}>{children}</UIAdaptersContext.Provider>;
}

export function useUIAdapters(): ResolvedAdapters {
  return useContext(UIAdaptersContext);
}
