/**
 * @file locales/index.ts
 * @description 공용 컴포넌트가 쓰는 문구의 5개 언어 리소스(ko·en·zh·vi·es).
 * 제품의 i18n 인스턴스에 합칠 때 제품이 이미 가진 키는 덮어쓰지 않는다.
 */
import type { i18n as I18n } from "i18next";
import ko from "./ko.json";
import en from "./en.json";
import zh from "./zh.json";
import vi from "./vi.json";
import es from "./es.json";

export type UiLanguage = "ko" | "en" | "zh" | "vi" | "es";

export const uiLocales: Record<UiLanguage, Record<string, unknown>> = { ko, en, zh, vi, es };

export function registerUiLocales(i18n: I18n): void {
  for (const [lng, res] of Object.entries(uiLocales)) {
    i18n.addResourceBundle(lng, "translation", res, true, false);
  }
}
