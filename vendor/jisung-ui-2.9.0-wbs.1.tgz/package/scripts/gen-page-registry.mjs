#!/usr/bin/env node
/**
 * @file scripts/gen-page-registry.mjs
 * @description 탭 keep-alive 용 페이지 레지스트리 생성기 (원본: HANES scripts/gen-page-registry.mjs).
 * 지정한 라우트 그룹 아래 모든 page.tsx 를 스캔해 경로 → lazy 동적 import 레지스트리를 만든다.
 *
 * 왜 codegen인가:
 * - 레이아웃 레벨 keep-alive(TabKeepAlive)는 활성 라우트뿐 아니라 열린 탭 페이지들을
 *   레이아웃이 직접 렌더해야 한다. Next의 {children}은 활성 라우트만 주므로 경로→컴포넌트 매핑이 필요하다.
 * - dev=Turbopack / build=webpack 환경에서 `import(`...${var}`)` 동적 표현식은 호환이 불확실하다.
 *   정적 import 목록을 생성하면 두 번들러 모두에서 안전하다.
 * - 동적 경로(`/csr/[id]`)는 정규식으로 매칭하고, 탭마다 자기 경로의 params 를 페이지에 넘긴다
 *   (props.params Promise + useRouteParams()). Next 의 useParams() 는 keep-alive 탭에서 쓰면 안 된다.
 *
 * 사용:
 *   node node_modules/@jisung/ui/scripts/gen-page-registry.mjs \
 *     --pages "src/app/(portal)" --out src/components/layout/pageRegistry.generated.ts
 * 옵션: --root <제품 프론트 루트, 기본 현재 폴더> --src <@/ 별칭 기준 폴더, 기본 src>
 *       --command "<머리 주석에 적을 재생성 명령>"
 */
import { mkdirSync, readdirSync, rmSync, statSync, writeFileSync } from "node:fs";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { compileRoute, sortDynamicRoutes } from "./route-pattern.mjs";

function parseArgs(argv) {
  const opts = {};
  for (let i = 0; i < argv.length; i += 2) {
    const key = argv[i];
    if (!key.startsWith("--") || argv[i + 1] === undefined) throw new Error(`잘못된 인자: ${key}`);
    opts[key.slice(2)] = argv[i + 1];
  }
  if (!opts.pages || !opts.out) {
    throw new Error('필수 인자: --pages "<라우트 그룹 폴더>" --out <레지스트리 파일>');
  }
  return opts;
}

const opts = parseArgs(process.argv.slice(2));
const FRONTEND_ROOT = resolve(opts.root ?? process.cwd());
const PAGES_ROOT = join(FRONTEND_ROOT, opts.pages);
const SRC_ROOT = join(FRONTEND_ROOT, opts.src ?? "src");
const OUT_FILE = join(FRONTEND_ROOT, opts.out);
const OUT_DIR = join(dirname(OUT_FILE), "page-registries");
const COMMAND = opts.command ?? "node node_modules/@jisung/ui/scripts/gen-page-registry.mjs";
const GROUP_LABEL = basename(PAGES_ROOT);
const rel = (p) => relative(FRONTEND_ROOT, p).replace(/\\/g, "/");

/** page.tsx 파일을 재귀적으로 수집 */
function collectPages(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) {
      out.push(...collectPages(full));
    } else if (name === "page.tsx") {
      out.push(full);
    }
  }
  return out;
}

/** 파일시스템 디렉터리(그룹 포함)를 URL 라우트 경로로 변환(그룹 `()` 세그먼트 제거) */
function toRoutePath(pageFile) {
  const relDir = relative(PAGES_ROOT, dirname(pageFile));
  const segments = relDir.split(sep).filter((s) => s && !/^\(.*\)$/.test(s));
  return "/" + segments.join("/");
}

/** import 지정자(파일시스템 경로 그대로, @/ 별칭 사용) */
function toImportSpec(pageFile) {
  const relFromSrc = relative(SRC_ROOT, pageFile)
    .replace(/\\/g, "/")
    .replace(/\.tsx$/, "");
  return "@/" + relFromSrc;
}

/** 정규식 소스를 /…/ 리터럴로. 문자 클래스 밖의 / 만 이스케이프한다. */
function toRegexLiteral(source) {
  let out = "";
  let inClass = false;
  for (const ch of source) {
    if (ch === "[") inClass = true;
    else if (ch === "]") inClass = false;
    out += ch === "/" && !inClass ? "\\/" : ch;
  }
  return `/${out}/`;
}

const pages = collectPages(PAGES_ROOT)
  .map((f) => ({ route: toRoutePath(f), spec: toImportSpec(f) }))
  .sort((a, b) => a.route.localeCompare(b.route));

const seen = new Map();
for (const p of pages) {
  if (seen.has(p.route)) {
    throw new Error(`중복 라우트 경로: ${p.route} (${p.spec} vs ${seen.get(p.route)})`);
  }
  seen.set(p.route, p.spec);
}

function registryName(route) {
  const parts = route.split("/").filter(Boolean);
  return (parts.length ? parts : ["root"])
    .join("__")
    .replace(/[^a-zA-Z0-9_-]/g, "-");
}

rmSync(OUT_DIR, { recursive: true, force: true });
mkdirSync(OUT_DIR, { recursive: true });

const staticPages = [];
const dynamicPages = [];
const registryNames = new Map();
for (const page of pages) {
  const name = registryName(page.route);
  const previous = registryNames.get(name);
  if (previous) {
    throw new Error(`Registry name collision: ${previous} and ${page.route} -> ${name}`);
  }
  registryNames.set(name, page.route);

  const compiled = compileRoute(page.route);
  const header = `/**
 * @file ${rel(join(OUT_DIR, `${name}.generated.ts`))}
 * @description 자동 생성 파일 — 직접 수정 금지. \`${COMMAND}\`로 재생성.
 */
`;
  let routeContent;
  if (!compiled.dynamic) {
    staticPages.push(page);
    routeContent = `${header}import dynamic from "next/dynamic";
import type { ComponentType } from "react";

export function getPageComponent(): ComponentType {
  return dynamic(() => import("${page.spec}"), { ssr: false });
}
`;
  } else {
    dynamicPages.push({ ...page, compiled });
    routeContent = `${header}import dynamic from "next/dynamic";
import { createElement, Suspense, type ComponentType } from "react";
import { RouteParamsProvider, type RouteParams } from "@jisung/ui";

const Page = dynamic(() => import("${page.spec}"), { ssr: false }) as ComponentType<{ params: Promise<RouteParams> }>;

/** 탭마다 자기 경로의 params 를 고정해 넘긴다. Next 15 페이지는 params 를 Promise 로 받는다. */
export function getPageComponent(params: RouteParams): ComponentType {
  const paramsPromise = Promise.resolve(params);
  function RoutedPage() {
    return createElement(RouteParamsProvider, {
      params,
      children: createElement(Suspense, { fallback: null }, createElement(Page, { params: paramsPromise })),
    });
  }
  return RoutedPage;
}
`;
  }

  writeFileSync(join(OUT_DIR, `${name}.generated.ts`), routeContent, "utf8");
}

const routeCases = staticPages
  .map(
    (page) => `    case "${page.route}": {
      const mod = await import("./page-registries/${registryName(page.route)}.generated");
      component = mod.getPageComponent();
      break;
    }`,
  )
  .join("\n");

const hasDynamic = dynamicPages.length > 0;
const dynamicBlock = hasDynamic
  ? `
type DynamicRoute = {
  pattern: RegExp;
  keys: { name: string; kind: "one" | "many" | "optional" }[];
  load: () => Promise<{ getPageComponent(params: RouteParams): ComponentType }>;
};

/** 동적 경로. 더 구체적인 경로가 앞에 온다. */
const dynamicRoutes: DynamicRoute[] = [
${sortDynamicRoutes(dynamicPages.map((p) => p.compiled))
  .map(
    (c) =>
      `  { pattern: ${toRegexLiteral(c.source)}, keys: [${c.keys.map((k) => `{ name: "${k.name}", kind: "${k.kind}" }`).join(", ")}], load: () => import("./page-registries/${registryName(c.route)}.generated") },`,
  )
  .join("\n")}
];

async function loadDynamicPage(path: string): Promise<ComponentType | null> {
  for (const route of dynamicRoutes) {
    const match = route.pattern.exec(path);
    if (!match) continue;
    const params: RouteParams = {};
    route.keys.forEach((key, i) => {
      const raw = match[i + 1];
      params[key.name] = key.kind === "one" ? decodeURIComponent(raw) : raw ? raw.split("/").map(decodeURIComponent) : [];
    });
    const mod = await route.load();
    return mod.getPageComponent(params);
  }
  return null;
}
`
  : "";

const content = `/**
 * @file ${rel(OUT_FILE)}
 * @description 자동 생성 파일 — 직접 수정 금지. \`${COMMAND}\`로 재생성.
 *              ${GROUP_LABEL} 영역 경로 → 페이지별 lazy dynamic factory.
 *              현재 경로의 작은 registry만 필요 시 import해 dev 서버의 전체 page compile 폭주를 피한다.
 */
import type { ComponentType } from "react";${hasDynamic ? '\nimport type { RouteParams } from "@jisung/ui";' : ""}

const pageComponentCache = new Map<string, ComponentType>();
const pageComponentPromiseCache = new Map<string, Promise<ComponentType | null>>();

export async function getPageComponent(path: string): Promise<ComponentType | null> {
  const cached = pageComponentCache.get(path);
  if (cached) return cached;

  const pending = pageComponentPromiseCache.get(path);
  if (pending) return pending;

  const promise = loadPageComponent(path);
  pageComponentPromiseCache.set(path, promise);
  const component = await promise;
  if (component) pageComponentCache.set(path, component);
  pageComponentPromiseCache.delete(path);
  return component;
}
${dynamicBlock}
async function loadPageComponent(path: string): Promise<ComponentType | null> {
  let component: ComponentType | null = null;
  switch (path) {
${routeCases}
    default:
      return ${hasDynamic ? "loadDynamicPage(path)" : "null"};
  }
  return component;
}
`;

writeFileSync(OUT_FILE, content, "utf8");
console.log(`Generated ${pages.length} route registries → ${rel(OUT_FILE)}`);
