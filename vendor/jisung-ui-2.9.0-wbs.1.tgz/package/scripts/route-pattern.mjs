/**
 * @file scripts/route-pattern.mjs
 * @description Next App Router 경로(`/csr/[id]`, `/docs/[...slug]`, `/help/[[...slug]]`)를 정규식으로 바꾸고
 * 실제 URL 경로에서 파라미터를 뽑는다. 페이지 레지스트리 생성기와 그 생성 결과가 같은 규칙을 쓴다.
 */

/** @typedef {{ name: string, kind: "one" | "many" | "optional" }} RouteKey */
/** @typedef {{ route: string, dynamic: boolean, source: string, keys: RouteKey[], staticCount: number }} CompiledRoute */

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** @returns {CompiledRoute} */
export function compileRoute(route) {
  const segments = route.split("/").filter(Boolean);
  const keys = [];
  let source = "^";
  let staticCount = 0;
  for (const seg of segments) {
    let m;
    if ((m = /^\[\[\.\.\.([^\]]+)\]\]$/.exec(seg))) {
      keys.push({ name: m[1], kind: "optional" });
      source += "(?:/(.+))?";
    } else if ((m = /^\[\.\.\.([^\]]+)\]$/.exec(seg))) {
      keys.push({ name: m[1], kind: "many" });
      source += "/(.+)";
    } else if ((m = /^\[([^\]]+)\]$/.exec(seg))) {
      keys.push({ name: m[1], kind: "one" });
      source += "/([^/]+)";
    } else {
      staticCount++;
      source += "/" + escapeRe(seg);
    }
  }
  if (!segments.length) source += "/";
  source += "/?$";
  return { route, dynamic: keys.length > 0, source, keys, staticCount };
}

/** @returns {Record<string, string | string[]> | null} */
export function matchRoute(compiled, path) {
  const m = new RegExp(compiled.source).exec(path);
  if (!m) return null;
  const params = {};
  compiled.keys.forEach((key, i) => {
    const raw = m[i + 1];
    if (key.kind === "one") params[key.name] = decodeURIComponent(raw);
    else params[key.name] = raw ? raw.split("/").map(decodeURIComponent) : [];
  });
  return params;
}

/** 세그먼트 자리마다 정적 > [x] > [...x] > [[...x]] 순으로 우선한다(Next 와 같은 규칙). 앞자리부터 비교. */
const rank = (seg) => (seg.startsWith("[[...") ? 3 : seg.startsWith("[...") ? 2 : seg.startsWith("[") ? 1 : 0);

export function sortDynamicRoutes(routes) {
  return [...routes].sort((a, b) => {
    const sa = a.route.split("/").filter(Boolean);
    const sb = b.route.split("/").filter(Boolean);
    for (let i = 0; i < Math.max(sa.length, sb.length); i++) {
      if (sa[i] === undefined) return 1;
      if (sb[i] === undefined) return -1;
      const d = rank(sa[i]) - rank(sb[i]);
      if (d) return d;
    }
    return a.route.localeCompare(b.route);
  });
}
